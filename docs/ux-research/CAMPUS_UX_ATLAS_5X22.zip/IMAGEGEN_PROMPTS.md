# Campus Atlas5 — 110 prompts ImageGen nativos (ES/EN)

**Estado:** textos de producción listos; **0 imágenes generadas**. No se dispone de ImageGen nativo en la ejecución de este worker. No presentar renders HTML, Canva, CLI o screenshots como originales.

**Identidad y fuente de verdad:** 22 superficies reales del inventario S00–S21, cinco direcciones A–E y escenario DEMO del sábado 24/10/2026. Los textos de materiales y apuntes son ejemplos para maqueta; no están confirmados en una cuenta. Todas las composiciones son FUTURO y requieren revisión del usuario.

**Método acreditado:** Juxtopposed [curso de UX](https://www.youtube.com/watch?v=wIuVvCuiJhU) (flujo → wireframes → design system → diseño), revisión de navegación completa de [YouTube](https://www.youtube.com/watch?v=OUM6XmhViN4) y [Steam](https://www.youtube.com/watch?v=cDY2p1CTkPo), y prueba contextual de color en [Realtime Colors](https://www.realtimecolors.com/docs/about-realtime-colors). Las direcciones A–E son interpretaciones de Campus, no creaciones de la autora.

**Contrato consumible en el HTML:** `ATLAS_SPEC.json` expone `directions` (cinco biblias visuales), `fixture` (datos canónicos), `screens[22]` (capacidades/fuentes), `proposals[110]` (una entrada por pareja). Seleccionar con `proposals.find(p => p.screenId === "S04" && p.directionId === "A")`. Campos principales: `headline`, `semanticContent.visibleCopy`, `layout.desktop/tablet/mobile`, `actionAffordances`, `improvementOverCode`, `responsive`, `implementation`, `imagegen.prompt`. Cada `imagegen.imageGenerated` es `false`; su ruta es `null`.

**Producción futura:** generar exactamente una composición por prompt y registrar original, dimensiones, fecha, hash y QA textual; usar primera dirección aprobada como ancla visual de los siguientes renders. Revisar primer lote S04, S05 y S13 en 390 y 1440 antes de ampliar a las 110.

## Biblia compartida por dirección

### A · Cuaderno editorial

La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Jerarquía: primero verbo y dato, luego contexto, al final acciones secundarias.

Tokens: fondo `#FAF8F3`, tinta `#202D2A`, acento `#176F68`, reglas `#D9DED5`; display Newsreader, interfaz Inter, cuerpo 15px; filetes de 1 px; subtítulos bajo la acción; espaciado de capítulo; títulos expresivos sin hero.

Responsive: Columna única, 16 px padding y bottom tabs; la primera tarea importante debe verse antes de plegar. Editor local abierto, explorer cerrado como propuesta. Tablet: Sidebar 220 px; evitar rail y tabla ancha, conservar lectura con saltos de línea. Desktop: Sidebar fija 220 px, documento a 52rem máximo; en calendario y vault uso full-bleed del canvas.

### B · Agenda de precisión

Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Jerarquía: etiqueta de hora/estado, nombre, materia; densidad sin microtipografía ilegible.

Tokens: fondo `#F6F8F5`, tinta `#18282C`, acento `#126A68`, reglas `#CBD9D7`; display Inter, interfaz Inter, cuerpo 14px; columna de hora tabular; estados en texto compacto; conteos pequeños; cabeceras adheridas a su sección.

Responsive: Una columna, primera línea título, metadatos debajo, 44 px de zona táctil; ninguna tabla horizontal. Tablet: Reducir metadatos secundarios y columnas; mantener títulos y hora sin truncamiento ambiguo. Desktop: Sidebar 220 px y columna de datos acotada o canvas entero en vista calendario; evitar KPI decorativos.

### C · Mesa contextual

Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Jerarquía: acción izquierda, contexto pertinente derecha solo con ancho y datos disponibles.

Tokens: fondo `#F7F6F0`, tinta `#233039`, acento `#226F7A`, reglas `#D7DEDA`; display Newsreader, interfaz Inter, cuerpo 15px; mesa de dos zonas; contexto de carrera solo cuando existe; líneas de columna en vez de tarjetas; sin rail vacío.

Responsive: El contexto pasa debajo de la tarea y nunca aparece una segunda columna sobre 390 px. Tablet: En 768 px colapsar contexto bajo bloque central; nunca dejar 220 px nav más rail permanente. Desktop: Con 1440 px, canvas posterior a nav admite columna principal 620px + contexto 270px; si no hay contexto, ensanchar lectura.

### D · Mapa académico

Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Jerarquía: la materia/hito activo arriba; Requiere y Habilita como listas semánticas si datos conocidos.

Tokens: fondo `#F6F8F2`, tinta `#20332E`, acento `#247362`, reglas `#D2DFD5`; display Newsreader, interfaz Inter, cuerpo 15px; líneas de relación solo entre datos conocidos; rutas textuales Requiere/Habilita; año y estado sin inferencias; estados desconocidos explícitos.

Responsive: Lista principal, una materia expandida con relaciones en texto; sin pan/zoom, sin nodos flotantes. Tablet: Detalle debajo de selección; vista mes/semana y tablas mantienen el motor real. Desktop: Dos zonas lista+detalle si hay relaciones o links reales; en formularios usar pasos explicativos, sin grafo artificial.

### E · Foco progresivo

Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Jerarquía: pregunta actual y CTA; detalle secundario agrupado sin eliminar estados críticos.

Tokens: fondo `#FAFBF6`, tinta `#172D29`, acento `#1B7465`, reglas `#D6E2D9`; display Newsreader, interfaz Inter, cuerpo 16px; una acción principal; bloques desplegables etiquetados; detalles secundarias después del dato urgente; confirmación textual.

Responsive: Pantalla con una decisión visible y secciones de detalles accesibles sin tocar; bottom tabs intactas donde aplican. Tablet: Una columna 500px netos en rutas normales, controles grandes y disclosure de detalles. Desktop: Centro estrecho 730px con espacios de decisión; no héroes vacíos ni asistentes inventados.

## Especificaciones de generación por pantalla

### S00 · Elegir espacio

**Código real:** `src/app/startup.tsx`, `src/app/folder-picker.tsx`. **Problema UX:** La elección local/Cloud requiere entender capacidad de carpeta y propiedad de los datos.

#### S00-A · Dos lugares, una decisión

**Layout desktop:** Sin shell; marca pequeña arriba; columna de 620px; dos bandas editoriales con título de opción, explicación y acción, separadas por filete.

**Layout móvil:** 390: pregunta en 2 líneas; opción local encima de Cloud si está disponible; acciones a ancho completo de 48px. Una decisión debajo de otra; no barra inferior antes del shell.

**Acción:** Botón Abrir carpeta y botón Usar Cloud con descripciones independientes. **Mejora:** La diferencia entre carpeta y cuenta se expresa antes de pedir elección.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S00-A, Elegir espacio.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Dónde querés trabajar?»; «Guardar en mi computadora»; «Usar Campus Cloud»; «Abrir otra carpeta».

DESKTOP 1440x900 WIREFRAME: Sin shell; marca pequeña arriba; columna de 620px; dos bandas editoriales con título de opción, explicación y acción, separadas por filete.

MOBILE 390x844 WIREFRAME: 390: pregunta en 2 líneas; opción local encima de Cloud si está disponible; acciones a ancho completo de 48px.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: logo → pregunta → opciones condicionadas → recientes/ayuda → estado error.

ACCIÓN VISIBLE / CONTROLS: Botón Abrir carpeta y botón Usar Cloud con descripciones independientes. Otras acciones reales relevantes: Elegir carpeta si vaultAvailable; Continuar con Campus Cloud; Recuperar carpeta disponible.

REALITY / FEASIBILITY: En web sin carpeta, mostrar solo Cloud; La carpeta local no requiere cuenta; No sugerir sincronización automática. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S00-B · Comparador de almacenamiento

**Layout desktop:** Sin shell; tabla editorial de dos filas anchas con columnas Dónde, Requisito, Acción; Cloud única fila cuando no hay carpeta.

**Layout móvil:** 390: convertir cada fila de comparación en tres renglones; no mostrar columnas estrechas. Una decisión debajo de otra; no barra inferior antes del shell.

**Acción:** Seleccionar opción mediante radio con leyenda y acción Continuar contextual. **Mejora:** Hace comprobable qué opción requiere cuenta y cuál guarda archivos en el equipo.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S00-B, Elegir espacio.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Dónde querés trabajar?»; «Guardar en mi computadora»; «Usar Campus Cloud»; «Abrir otra carpeta».

DESKTOP 1440x900 WIREFRAME: Sin shell; tabla editorial de dos filas anchas con columnas Dónde, Requisito, Acción; Cloud única fila cuando no hay carpeta.

MOBILE 390x844 WIREFRAME: 390: convertir cada fila de comparación en tres renglones; no mostrar columnas estrechas.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: logo → pregunta → opciones condicionadas → recientes/ayuda → estado error.

ACCIÓN VISIBLE / CONTROLS: Seleccionar opción mediante radio con leyenda y acción Continuar contextual. Otras acciones reales relevantes: Elegir carpeta si vaultAvailable; Continuar con Campus Cloud; Recuperar carpeta disponible.

REALITY / FEASIBILITY: En web sin carpeta, mostrar solo Cloud; La carpeta local no requiere cuenta; No sugerir sincronización automática. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S00-C · Empezar con contexto visible

**Layout desktop:** Columna principal 440px con elecciones y franja 240px de condiciones reales: carpeta disponible / cuenta requerida; sin rail si solo Cloud.

**Layout móvil:** 390: nota de privacidad debajo de cada elección, no columna auxiliar. Una decisión debajo de otra; no barra inferior antes del shell.

**Acción:** Detalle «¿Dónde se guardan?» expandible al lado de cada opción. **Mejora:** Ubica consecuencias de elegir Cloud/local junto a la opción, sin introducir sync.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S00-C, Elegir espacio.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Dónde querés trabajar?»; «Guardar en mi computadora»; «Usar Campus Cloud»; «Abrir otra carpeta».

DESKTOP 1440x900 WIREFRAME: Columna principal 440px con elecciones y franja 240px de condiciones reales: carpeta disponible / cuenta requerida; sin rail si solo Cloud.

MOBILE 390x844 WIREFRAME: 390: nota de privacidad debajo de cada elección, no columna auxiliar.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: logo → pregunta → opciones condicionadas → recientes/ayuda → estado error.

ACCIÓN VISIBLE / CONTROLS: Detalle «¿Dónde se guardan?» expandible al lado de cada opción. Otras acciones reales relevantes: Elegir carpeta si vaultAvailable; Continuar con Campus Cloud; Recuperar carpeta disponible.

REALITY / FEASIBILITY: En web sin carpeta, mostrar solo Cloud; La carpeta local no requiere cuenta; No sugerir sincronización automática. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S00-D · Ruta de ingreso explicada

**Layout desktop:** Diagrama textual de dos trayectos en una hoja 700px: Carpeta → cursada local; Cloud → acceso → plan; nodos planos no interactivos.

**Layout móvil:** 390: dos secuencias apiladas con flechas de texto, botón en cada ruta admitida. Una decisión debajo de otra; no barra inferior antes del shell.

**Acción:** Acción de continuar asociada a cada ruta, sin atajo que omita login Cloud. **Mejora:** Explicita el recorrido real hasta Hoy, relevante para quien abre Campus por primera vez.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S00-D, Elegir espacio.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Dónde querés trabajar?»; «Guardar en mi computadora»; «Usar Campus Cloud»; «Abrir otra carpeta».

DESKTOP 1440x900 WIREFRAME: Diagrama textual de dos trayectos en una hoja 700px: Carpeta → cursada local; Cloud → acceso → plan; nodos planos no interactivos.

MOBILE 390x844 WIREFRAME: 390: dos secuencias apiladas con flechas de texto, botón en cada ruta admitida.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: logo → pregunta → opciones condicionadas → recientes/ayuda → estado error.

ACCIÓN VISIBLE / CONTROLS: Acción de continuar asociada a cada ruta, sin atajo que omita login Cloud. Otras acciones reales relevantes: Elegir carpeta si vaultAvailable; Continuar con Campus Cloud; Recuperar carpeta disponible.

REALITY / FEASIBILITY: En web sin carpeta, mostrar solo Cloud; La carpeta local no requiere cuenta; No sugerir sincronización automática. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S00-E · Primero elegí dónde guardar

**Layout desktop:** Una pregunta en 550px; opción recomendada solamente cuando la capacidad runtime la permite, segunda elección visible debajo con descripción.

**Layout móvil:** 390: primer viewport muestra pregunta y opciones completas; texto técnico bajo «¿Qué significa?». Una decisión debajo de otra; no barra inferior antes del shell.

**Acción:** Botones grandes; expansión «Ver diferencia» revela cuenta/carpetas sin bloquear la elección. **Mejora:** Reduce la carga de explicar persistencia sin ocultar alternativas disponibles.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S00-E, Elegir espacio.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Dónde querés trabajar?»; «Guardar en mi computadora»; «Usar Campus Cloud»; «Abrir otra carpeta».

DESKTOP 1440x900 WIREFRAME: Una pregunta en 550px; opción recomendada solamente cuando la capacidad runtime la permite, segunda elección visible debajo con descripción.

MOBILE 390x844 WIREFRAME: 390: primer viewport muestra pregunta y opciones completas; texto técnico bajo «¿Qué significa?».

Muestra el viewport solicitado 390x844 con esta estructura y priorización: logo → pregunta → opciones condicionadas → recientes/ayuda → estado error.

ACCIÓN VISIBLE / CONTROLS: Botones grandes; expansión «Ver diferencia» revela cuenta/carpetas sin bloquear la elección. Otras acciones reales relevantes: Elegir carpeta si vaultAvailable; Continuar con Campus Cloud; Recuperar carpeta disponible.

REALITY / FEASIBILITY: En web sin carpeta, mostrar solo Cloud; La carpeta local no requiere cuenta; No sugerir sincronización automática. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S01 · Acceso Cloud

**Código real:** `src/routes/login.tsx`. **Problema UX:** Dos modos entrar/registro comparten formulario y mensajes de error que necesitan orientación Cloud.

#### S01-A · Entrar sin distracciones

**Layout desktop:** Área de 420px con «Entrar a Campus Cloud», email y contraseña como renglones de hoja; error inline y submit al pie.

**Layout móvil:** 390: back-link superior; campos y submit 48px, alternar registro debajo de la regla. Formulario una columna con teclado visible, CTA alcanzable.

**Acción:** Enlace «Crear cuenta» cambia modo y muestra Nombre solo en registro. **Mejora:** Separa acceso a cuenta de elección de carpeta y destaca error junto al campo.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S01-A, Acceso Cloud.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Entrar a Campus Cloud»; «Email»; «Contraseña»; «Crear cuenta»; «Volver a elegir espacio».

DESKTOP 1440x900 WIREFRAME: Área de 420px con «Entrar a Campus Cloud», email y contraseña como renglones de hoja; error inline y submit al pie.

MOBILE 390x844 WIREFRAME: 390: back-link superior; campos y submit 48px, alternar registro debajo de la regla.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → identidad cloud → formulario → error → submit → cambio de modo.

ACCIÓN VISIBLE / CONTROLS: Enlace «Crear cuenta» cambia modo y muestra Nombre solo en registro. Otras acciones reales relevantes: Entrar; Alternar crear cuenta/entrar; Volver al selector.

REALITY / FEASIBILITY: Nombre solo en registro; No dibujar SSO ni recuperar clave sin backend; Mantener error y pendiente. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S01-B · Credenciales a primera vista

**Layout desktop:** Formulario 440px con labels alineadas a campos, validación visible y estado del botón al enviar; pie pequeño Cloud.

**Layout móvil:** 390: labels sobre inputs, feedback justo bajo contraseña, sin dos columnas. Formulario una columna con teclado visible, CTA alcanzable.

**Acción:** Estado Entrando… en submit sin perder el texto del error. **Mejora:** Acorta barrido entre identidad Cloud, datos necesarios y acción.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S01-B, Acceso Cloud.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Entrar a Campus Cloud»; «Email»; «Contraseña»; «Crear cuenta»; «Volver a elegir espacio».

DESKTOP 1440x900 WIREFRAME: Formulario 440px con labels alineadas a campos, validación visible y estado del botón al enviar; pie pequeño Cloud.

MOBILE 390x844 WIREFRAME: 390: labels sobre inputs, feedback justo bajo contraseña, sin dos columnas.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → identidad cloud → formulario → error → submit → cambio de modo.

ACCIÓN VISIBLE / CONTROLS: Estado Entrando… en submit sin perder el texto del error. Otras acciones reales relevantes: Entrar; Alternar crear cuenta/entrar; Volver al selector.

REALITY / FEASIBILITY: Nombre solo en registro; No dibujar SSO ni recuperar clave sin backend; Mantener error y pendiente. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S01-C · Cuenta y procedencia

**Layout desktop:** Formulario 430px a la izquierda y panel de 250px solo explicativo «Estás entrando a Campus Cloud» a la derecha.

**Layout móvil:** 390: la explicación Cloud va antes del primer campo, texto de una línea. Formulario una columna con teclado visible, CTA alcanzable.

**Acción:** Volver a elegir espacio al lado de encabezado, no salida de sesión ficticia. **Mejora:** Recuerda que es una cuenta Cloud, evitando confusión con el vault local.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S01-C, Acceso Cloud.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Entrar a Campus Cloud»; «Email»; «Contraseña»; «Crear cuenta»; «Volver a elegir espacio».

DESKTOP 1440x900 WIREFRAME: Formulario 430px a la izquierda y panel de 250px solo explicativo «Estás entrando a Campus Cloud» a la derecha.

MOBILE 390x844 WIREFRAME: 390: la explicación Cloud va antes del primer campo, texto de una línea.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → identidad cloud → formulario → error → submit → cambio de modo.

ACCIÓN VISIBLE / CONTROLS: Volver a elegir espacio al lado de encabezado, no salida de sesión ficticia. Otras acciones reales relevantes: Entrar; Alternar crear cuenta/entrar; Volver al selector.

REALITY / FEASIBILITY: Nombre solo en registro; No dibujar SSO ni recuperar clave sin backend; Mantener error y pendiente. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S01-D · Acceso como paso del recorrido

**Layout desktop:** Progreso textual «Espacio → Cuenta → Carrera» sobre formulario 440px; paso Cuenta resaltado, demás descriptivos.

**Layout móvil:** 390: una secuencia breve por encima de email, sin gráfico de nodos. Formulario una columna con teclado visible, CTA alcanzable.

**Acción:** Volver regresa a selector; Crear cuenta conserva el mismo paso. **Mejora:** Hace visible por qué se pide cuenta al elegir Cloud y cuál paso viene después.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S01-D, Acceso Cloud.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Entrar a Campus Cloud»; «Email»; «Contraseña»; «Crear cuenta»; «Volver a elegir espacio».

DESKTOP 1440x900 WIREFRAME: Progreso textual «Espacio → Cuenta → Carrera» sobre formulario 440px; paso Cuenta resaltado, demás descriptivos.

MOBILE 390x844 WIREFRAME: 390: una secuencia breve por encima de email, sin gráfico de nodos.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → identidad cloud → formulario → error → submit → cambio de modo.

ACCIÓN VISIBLE / CONTROLS: Volver regresa a selector; Crear cuenta conserva el mismo paso. Otras acciones reales relevantes: Entrar; Alternar crear cuenta/entrar; Volver al selector.

REALITY / FEASIBILITY: Nombre solo en registro; No dibujar SSO ni recuperar clave sin backend; Mantener error y pendiente. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S01-E · Una acción: entrar

**Layout desktop:** Formulario contenido 420px; email/password primarios, registro revelado por enlace, privacidad al final.

**Layout móvil:** 390: CTA Entrar visible antes del fold, sin ilustración ni slogans. Formulario una columna con teclado visible, CTA alcanzable.

**Acción:** Tocar «Primera vez acá» cambia a nombre/email/clave y CTA Crear cuenta. **Mejora:** Elimina competencia visual entre entrar y crear cuenta manteniendo ambas rutas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S01-E, Acceso Cloud.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Entrar a Campus Cloud»; «Email»; «Contraseña»; «Crear cuenta»; «Volver a elegir espacio».

DESKTOP 1440x900 WIREFRAME: Formulario contenido 420px; email/password primarios, registro revelado por enlace, privacidad al final.

MOBILE 390x844 WIREFRAME: 390: CTA Entrar visible antes del fold, sin ilustración ni slogans.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → identidad cloud → formulario → error → submit → cambio de modo.

ACCIÓN VISIBLE / CONTROLS: Tocar «Primera vez acá» cambia a nombre/email/clave y CTA Crear cuenta. Otras acciones reales relevantes: Entrar; Alternar crear cuenta/entrar; Volver al selector.

REALITY / FEASIBILITY: Nombre solo en registro; No dibujar SSO ni recuperar clave sin backend; Mantener error y pendiente. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S02 · Elegir plan académico

**Código real:** `src/routes/onboarding.tsx`. **Problema UX:** La secuencia Universidad/Facultad/Carrera/Plan puede sentirse larga si el estudiante no sabe en qué paso está.

#### S02-A · Tu carrera, como una ficha

**Layout desktop:** Cabecera editorial y fila de progreso de cuatro nombres; fieldsets verticales 700px, elegido anterior mostrado como línea resumen.

**Layout móvil:** 390: Universidad/F. Regional/Carrera/Plan en microprogreso de dos líneas; radios 48px. Preguntar una selección por vez, opciones en filas táctiles.

**Acción:** Cambiar universidad reabre fieldset y reinicia selección dependiente. **Mejora:** Aumenta legibilidad de elecciones y de la salida manual sin añadir paso.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S02-A, Elegir plan académico.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos dónde estudiás»; «UTN»; «Facultad Regional Rosario»; «Ingeniería en Sistemas de Información»; «Plan 2023»; «No encuentro mi carrera».

DESKTOP 1440x900 WIREFRAME: Cabecera editorial y fila de progreso de cuatro nombres; fieldsets verticales 700px, elegido anterior mostrado como línea resumen.

MOBILE 390x844 WIREFRAME: 390: Universidad/F. Regional/Carrera/Plan en microprogreso de dos líneas; radios 48px.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: orientación → progreso → selección actual → resumen previo → salida manual.

ACCIÓN VISIBLE / CONTROLS: Cambiar universidad reabre fieldset y reinicia selección dependiente. Otras acciones reales relevantes: Elegir opción de cada fieldset; Cambiar elección anterior; Continuar o usar plan manual.

REALITY / FEASIBILITY: Datos desde catálogo real; No crear carrera/facultad no publicada; Elegir superior resetea descendientes. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S02-B · Cuatro decisiones trazables

**Layout desktop:** Wizard 720px con stepper numerado 1–4 y conteo de opciones cargadas; radio filas densas y selección marcada.

**Layout móvil:** 390: stepper con etiquetas abreviadas y estado actual; fieldset completo a una columna. Preguntar una selección por vez, opciones en filas táctiles.

**Acción:** Selección por radio y resumen de valor; botón Continuar habilitado solo con plan. **Mejora:** Aclara cuál dato falta para habilitar «Listo, empezar».

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S02-B, Elegir plan académico.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos dónde estudiás»; «UTN»; «Facultad Regional Rosario»; «Ingeniería en Sistemas de Información»; «Plan 2023»; «No encuentro mi carrera».

DESKTOP 1440x900 WIREFRAME: Wizard 720px con stepper numerado 1–4 y conteo de opciones cargadas; radio filas densas y selección marcada.

MOBILE 390x844 WIREFRAME: 390: stepper con etiquetas abreviadas y estado actual; fieldset completo a una columna.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: orientación → progreso → selección actual → resumen previo → salida manual.

ACCIÓN VISIBLE / CONTROLS: Selección por radio y resumen de valor; botón Continuar habilitado solo con plan. Otras acciones reales relevantes: Elegir opción de cada fieldset; Cambiar elección anterior; Continuar o usar plan manual.

REALITY / FEASIBILITY: Datos desde catálogo real; No crear carrera/facultad no publicada; Elegir superior resetea descendientes. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S02-C · Elegí con el camino a la vista

**Layout desktop:** Selector 520px a la izquierda; resumen de Universidad/Regional/Carrera/Plan 220px derecha, mostrando solo decisiones hechas.

**Layout móvil:** 390: resumen posterior al campo actual; sin rail. Preguntar una selección por vez, opciones en filas táctiles.

**Acción:** Cada valor del resumen tiene «Cambiar» al fieldset existente. **Mejora:** Ayuda a reconocer un plan accidental sin pedir nuevos datos.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S02-C, Elegir plan académico.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos dónde estudiás»; «UTN»; «Facultad Regional Rosario»; «Ingeniería en Sistemas de Información»; «Plan 2023»; «No encuentro mi carrera».

DESKTOP 1440x900 WIREFRAME: Selector 520px a la izquierda; resumen de Universidad/Regional/Carrera/Plan 220px derecha, mostrando solo decisiones hechas.

MOBILE 390x844 WIREFRAME: 390: resumen posterior al campo actual; sin rail.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: orientación → progreso → selección actual → resumen previo → salida manual.

ACCIÓN VISIBLE / CONTROLS: Cada valor del resumen tiene «Cambiar» al fieldset existente. Otras acciones reales relevantes: Elegir opción de cada fieldset; Cambiar elección anterior; Continuar o usar plan manual.

REALITY / FEASIBILITY: Datos desde catálogo real; No crear carrera/facultad no publicada; Elegir superior resetea descendientes. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S02-D · Árbol académico sin inventar opciones

**Layout desktop:** Cuatro columnas secuenciales Universidad → Regional → Carrera → Plan; la rama real UTN/FRRo/ISI/2023 se traza con guías.

**Layout móvil:** 390: una rama expandida por vez, etapas previas como texto enlazado. Preguntar una selección por vez, opciones en filas táctiles.

**Acción:** Volver a etapa previa invalida solo opciones que ya no corresponden. **Mejora:** Explica dependencia entre campos y por qué una opción superior cambia descendientes.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S02-D, Elegir plan académico.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos dónde estudiás»; «UTN»; «Facultad Regional Rosario»; «Ingeniería en Sistemas de Información»; «Plan 2023»; «No encuentro mi carrera».

DESKTOP 1440x900 WIREFRAME: Cuatro columnas secuenciales Universidad → Regional → Carrera → Plan; la rama real UTN/FRRo/ISI/2023 se traza con guías.

MOBILE 390x844 WIREFRAME: 390: una rama expandida por vez, etapas previas como texto enlazado.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: orientación → progreso → selección actual → resumen previo → salida manual.

ACCIÓN VISIBLE / CONTROLS: Volver a etapa previa invalida solo opciones que ya no corresponden. Otras acciones reales relevantes: Elegir opción de cada fieldset; Cambiar elección anterior; Continuar o usar plan manual.

REALITY / FEASIBILITY: Datos desde catálogo real; No crear carrera/facultad no publicada; Elegir superior resetea descendientes. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S02-E · Elegí tu universidad

**Layout desktop:** Un fieldset visible por vez, selección válida abre el siguiente; cuatro hitos arriba y resumen editable debajo.

**Layout móvil:** 390: título pregunta, radios grandes, CTA siguiente; salida manual siempre visible. Preguntar una selección por vez, opciones en filas táctiles.

**Acción:** Radio autoselecciona única opción como comportamiento real; «No encuentro mi carrera» accesible. **Mejora:** Reduce longitud perceptiva del wizard y conserva ruta manual para plan no catalogado.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S02-E, Elegir plan académico.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos dónde estudiás»; «UTN»; «Facultad Regional Rosario»; «Ingeniería en Sistemas de Información»; «Plan 2023»; «No encuentro mi carrera».

DESKTOP 1440x900 WIREFRAME: Un fieldset visible por vez, selección válida abre el siguiente; cuatro hitos arriba y resumen editable debajo.

MOBILE 390x844 WIREFRAME: 390: título pregunta, radios grandes, CTA siguiente; salida manual siempre visible.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: orientación → progreso → selección actual → resumen previo → salida manual.

ACCIÓN VISIBLE / CONTROLS: Radio autoselecciona única opción como comportamiento real; «No encuentro mi carrera» accesible. Otras acciones reales relevantes: Elegir opción de cada fieldset; Cambiar elección anterior; Continuar o usar plan manual.

REALITY / FEASIBILITY: Datos desde catálogo real; No crear carrera/facultad no publicada; Elegir superior resetea descendientes. Sin AcademicShell; marca Campus y regreso adecuado al flujo. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S03 · Registrar avance

**Código real:** `src/features/academic/progress-entry-screen.tsx`. **Problema UX:** Distinguir aprobado, regularizado y cursando y hacer visible que cada edición guarda automáticamente.

#### S03-A · Marcá el avance por año

**Layout desktop:** Columna 820px, encabezado «Contanos hasta dónde llegaste», explicación de regularizada y años con filas separadas; status escrito.

**Layout móvil:** 390: materia encima de selector de estado, botones de aprobar año bajo encabezado. Estados debajo del nombre y CTA aprobar año en su encabezado.

**Acción:** Guardar automático con «Guardado» por fila; aprobar año muestra Deshacer. **Mejora:** La diferencia regularizada/aprobada se explica antes de editar el primer estado.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S03-A, Registrar avance.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos hasta dónde llegaste»; «Regularizada: cursada terminada; falta el final»; «1.º año»; «2.º año»; «Aprobé todo el año»; «Deshacer»; «Guardado».

DESKTOP 1440x900 WIREFRAME: Columna 820px, encabezado «Contanos hasta dónde llegaste», explicación de regularizada y años con filas separadas; status escrito.

MOBILE 390x844 WIREFRAME: 390: materia encima de selector de estado, botones de aprobar año bajo encabezado.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → explicación regularizada → años → filas de estado → feedback/autoguardado → continuar.

ACCIÓN VISIBLE / CONTROLS: Guardar automático con «Guardado» por fila; aprobar año muestra Deshacer. Otras acciones reales relevantes: Cambiar estado de materia; Aprobar todo un año; Deshacer lote; Terminar revisión.

REALITY / FEASIBILITY: No inventar total/porcentaje de año; Los controles de estado usan dominio real; No botón Guardar global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S03-B · Estados bajo control

**Layout desktop:** Filas 50px en tres zonas Materia/Estado/Guardado; contador aprobadas/total de cada año solo si fuente lo calcula.

**Layout móvil:** 390: estado queda debajo de materia, contador en encabezado; no tabla horizontal. Estados debajo del nombre y CTA aprobar año en su encabezado.

**Acción:** Selector de estado compacto y atajo a «Aprobé todo» por año. **Mejora:** Acelera registrar varias materias manteniendo visibilidad de cada guardado.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S03-B, Registrar avance.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos hasta dónde llegaste»; «Regularizada: cursada terminada; falta el final»; «1.º año»; «2.º año»; «Aprobé todo el año»; «Deshacer»; «Guardado».

DESKTOP 1440x900 WIREFRAME: Filas 50px en tres zonas Materia/Estado/Guardado; contador aprobadas/total de cada año solo si fuente lo calcula.

MOBILE 390x844 WIREFRAME: 390: estado queda debajo de materia, contador en encabezado; no tabla horizontal.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → explicación regularizada → años → filas de estado → feedback/autoguardado → continuar.

ACCIÓN VISIBLE / CONTROLS: Selector de estado compacto y atajo a «Aprobé todo» por año. Otras acciones reales relevantes: Cambiar estado de materia; Aprobar todo un año; Deshacer lote; Terminar revisión.

REALITY / FEASIBILITY: No inventar total/porcentaje de año; Los controles de estado usan dominio real; No botón Guardar global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S03-C · Avance y significado juntos

**Layout desktop:** Lista de un año 600px izquierda y explicación contextual 240px derecha para «Regularizada», «Equivalente», conflictos.

**Layout móvil:** 390: explicación aparece en bloque bajo leyenda de estados, lista después. Estados debajo del nombre y CTA aprobar año en su encabezado.

**Acción:** Cambiar estado actualiza ayuda contextual; lote Deshacer permanece visible. **Mejora:** Pone la definición del estado cerca de la elección compleja.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S03-C, Registrar avance.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos hasta dónde llegaste»; «Regularizada: cursada terminada; falta el final»; «1.º año»; «2.º año»; «Aprobé todo el año»; «Deshacer»; «Guardado».

DESKTOP 1440x900 WIREFRAME: Lista de un año 600px izquierda y explicación contextual 240px derecha para «Regularizada», «Equivalente», conflictos.

MOBILE 390x844 WIREFRAME: 390: explicación aparece en bloque bajo leyenda de estados, lista después.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → explicación regularizada → años → filas de estado → feedback/autoguardado → continuar.

ACCIÓN VISIBLE / CONTROLS: Cambiar estado actualiza ayuda contextual; lote Deshacer permanece visible. Otras acciones reales relevantes: Cambiar estado de materia; Aprobar todo un año; Deshacer lote; Terminar revisión.

REALITY / FEASIBILITY: No inventar total/porcentaje de año; Los controles de estado usan dominio real; No botón Guardar global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S03-D · Años y camino ya recorrido

**Layout desktop:** Bandas de años con materias por estado; pequeña guía textual «Cursando → Regularizada → Aprobada» sin forzar secuencia legal universal.

**Layout móvil:** 390: ruta de términos como glosario, materias por año y selector expandido. Estados debajo del nombre y CTA aprobar año en su encabezado.

**Acción:** Cada año incluye acción de marcado masivo y reversión inmediata. **Mejora:** Ayuda a separar cursada y examen final mientras deja elegir cualquier estado permitido.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S03-D, Registrar avance.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos hasta dónde llegaste»; «Regularizada: cursada terminada; falta el final»; «1.º año»; «2.º año»; «Aprobé todo el año»; «Deshacer»; «Guardado».

DESKTOP 1440x900 WIREFRAME: Bandas de años con materias por estado; pequeña guía textual «Cursando → Regularizada → Aprobada» sin forzar secuencia legal universal.

MOBILE 390x844 WIREFRAME: 390: ruta de términos como glosario, materias por año y selector expandido.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → explicación regularizada → años → filas de estado → feedback/autoguardado → continuar.

ACCIÓN VISIBLE / CONTROLS: Cada año incluye acción de marcado masivo y reversión inmediata. Otras acciones reales relevantes: Cambiar estado de materia; Aprobar todo un año; Deshacer lote; Terminar revisión.

REALITY / FEASIBILITY: No inventar total/porcentaje de año; Los controles de estado usan dominio real; No botón Guardar global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S03-E · Completá un año a la vez

**Layout desktop:** Un año abierto en columna 740px; otros como encabezados plegables, texto regularizada visible permanentemente.

**Layout móvil:** 390: un año expandido, selector de materia ocupa ancho completo, botón Terminar al final. Estados debajo del nombre y CTA aprobar año en su encabezado.

**Acción:** Botón «Siguiente año» desplaza foco y «Deshacer» aparece tras el lote. **Mejora:** Reduce el volumen inicial sin esconder que hay varios años pendientes.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S03-E, Registrar avance.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Contanos hasta dónde llegaste»; «Regularizada: cursada terminada; falta el final»; «1.º año»; «2.º año»; «Aprobé todo el año»; «Deshacer»; «Guardado».

DESKTOP 1440x900 WIREFRAME: Un año abierto en columna 740px; otros como encabezados plegables, texto regularizada visible permanentemente.

MOBILE 390x844 WIREFRAME: 390: un año expandido, selector de materia ocupa ancho completo, botón Terminar al final.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → explicación regularizada → años → filas de estado → feedback/autoguardado → continuar.

ACCIÓN VISIBLE / CONTROLS: Botón «Siguiente año» desplaza foco y «Deshacer» aparece tras el lote. Otras acciones reales relevantes: Cambiar estado de materia; Aprobar todo un año; Deshacer lote; Terminar revisión.

REALITY / FEASIBILITY: No inventar total/porcentaje de año; Los controles de estado usan dominio real; No botón Guardar global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S04 · Hoy

**Código real:** `src/routes/_app/today.tsx`, `docs/ux-research/proposals/SCENARIO.md`. **Problema UX:** El orden Atrasadas/Hoy/Próximas ya existe, pero la jerarquía y densidad pueden dificultar distinguir vencidos y horas.

#### S04-A · Hoy, una página que se lee

**Layout desktop:** Sidebar 220; columna 832px con fecha Newsreader, titular y reglas Atrasadas/Hoy/Próximas/Sin fecha; materias debajo.

**Layout móvil:** 390: primera fila TP 2 atrasado inmediatamente después del título; tabs + FAB al pie sin solape. Primera vencida sobre fold; bottom tab + FAB sin pisar último renglón.

**Acción:** Círculos 20px con hit area 44px; «Ver calendario» debajo de Próximas. **Mejora:** El vencimiento se ve antes que progreso de carrera, eliminando jerarquía KPI.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S04-A, Hoy.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Sábado 24 de octubre»; «Tenés 3 cosas para hoy.»; «Atrasadas»; «TP 2 · atrasado · Arquitectura de Computadoras · 21 oct 18:00»; «Hoy»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Próximas»; «Primer parcial · 25 oct 08:00»; «Informe de laboratorio · 28 oct 20:00»; «Sin fecha · Pedir apuntes a Belén».

DESKTOP 1440x900 WIREFRAME: Sidebar 220; columna 832px con fecha Newsreader, titular y reglas Atrasadas/Hoy/Próximas/Sin fecha; materias debajo.

MOBILE 390x844 WIREFRAME: 390: primera fila TP 2 atrasado inmediatamente después del título; tabs + FAB al pie sin solape.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: fecha → titular → atrasadas → hoy → próximas → sin fecha → cursando → final pendiente → avance.

ACCIÓN VISIBLE / CONTROLS: Círculos 20px con hit area 44px; «Ver calendario» debajo de Próximas. Otras acciones reales relevantes: Marcar tarea hecha; Abrir materia; Ver calendario; Agregar fecha o tarea.

REALITY / FEASIBILITY: Contar 1 atrasada + 2 hoy = 3; Sin datos de productividad o cronómetro; No mostrar final fuera de horizonte 14 días. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S04-B · Agenda horaria de seis filas

**Layout desktop:** Sidebar 220; banda de 850px con columna de hora 74px y checkbox/título/metadatos; secciones de 48px con contadores 1/2/2/1.

**Layout móvil:** 390: horas debajo de título si no cabe; seis filas legibles y materias bajo «Más abajo». Primera vencida sobre fold; bottom tab + FAB sin pisar último renglón.

**Acción:** Check por obligación y enlace a materia en segunda línea, orden ya dado por today-model. **Mejora:** Permite cotejar rápidamente 09:00,18:00 y mañana 08:00 sin perder prioridad vencida.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S04-B, Hoy.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Sábado 24 de octubre»; «Tenés 3 cosas para hoy.»; «Atrasadas»; «TP 2 · atrasado · Arquitectura de Computadoras · 21 oct 18:00»; «Hoy»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Próximas»; «Primer parcial · 25 oct 08:00»; «Informe de laboratorio · 28 oct 20:00»; «Sin fecha · Pedir apuntes a Belén».

DESKTOP 1440x900 WIREFRAME: Sidebar 220; banda de 850px con columna de hora 74px y checkbox/título/metadatos; secciones de 48px con contadores 1/2/2/1.

MOBILE 390x844 WIREFRAME: 390: horas debajo de título si no cabe; seis filas legibles y materias bajo «Más abajo».

Muestra el viewport solicitado 390x844 con esta estructura y priorización: fecha → titular → atrasadas → hoy → próximas → sin fecha → cursando → final pendiente → avance.

ACCIÓN VISIBLE / CONTROLS: Check por obligación y enlace a materia en segunda línea, orden ya dado por today-model. Otras acciones reales relevantes: Marcar tarea hecha; Abrir materia; Ver calendario; Agregar fecha o tarea.

REALITY / FEASIBILITY: Contar 1 atrasada + 2 hoy = 3; Sin datos de productividad o cronómetro; No mostrar final fuera de horizonte 14 días. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S04-C · Tu día y tus materias

**Layout desktop:** Sidebar 220; agenda izquierda 620px con TP2/Teoría/TP4/Próximas; panel lateral 270px para Cursando y Final pendiente existentes.

**Layout móvil:** 390: panel Cursando/Final pendiente pasa debajo de Próximas, arriba de avance; título prioriza TP2. Primera vencida sobre fold; bottom tab + FAB sin pisar último renglón.

**Acción:** Cada materia del panel abre su detalle; entregas se marcan en agenda. **Mejora:** Reutiliza materias existentes en contexto lateral sin introducir métricas ni nuevos modelos.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S04-C, Hoy.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Sábado 24 de octubre»; «Tenés 3 cosas para hoy.»; «Atrasadas»; «TP 2 · atrasado · Arquitectura de Computadoras · 21 oct 18:00»; «Hoy»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Próximas»; «Primer parcial · 25 oct 08:00»; «Informe de laboratorio · 28 oct 20:00»; «Sin fecha · Pedir apuntes a Belén».

DESKTOP 1440x900 WIREFRAME: Sidebar 220; agenda izquierda 620px con TP2/Teoría/TP4/Próximas; panel lateral 270px para Cursando y Final pendiente existentes.

MOBILE 390x844 WIREFRAME: 390: panel Cursando/Final pendiente pasa debajo de Próximas, arriba de avance; título prioriza TP2.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: fecha → titular → atrasadas → hoy → próximas → sin fecha → cursando → final pendiente → avance.

ACCIÓN VISIBLE / CONTROLS: Cada materia del panel abre su detalle; entregas se marcan en agenda. Otras acciones reales relevantes: Marcar tarea hecha; Abrir materia; Ver calendario; Agregar fecha o tarea.

REALITY / FEASIBILITY: Contar 1 atrasada + 2 hoy = 3; Sin datos de productividad o cronómetro; No mostrar final fuera de horizonte 14 días. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S04-D · Hoy conectado a la carrera

**Layout desktop:** Sidebar; lista Atrasadas/Hoy 600px, franja «Materia» 270px con enlace a correlativas verificadas solo desde una materia elegida.

**Layout móvil:** 390: la acción «Ver materia» conduce a requisitos; no mapa ni bloque lateral. Primera vencida sobre fold; bottom tab + FAB sin pisar último renglón.

**Acción:** «Ver Análisis Matemático II» junto a Primer parcial; «Correlativas» solo en detalle si hay datos. **Mejora:** Hace descubrible la relación entre fecha y asignatura sin fingir correlativas de plan desconocido.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S04-D, Hoy.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Sábado 24 de octubre»; «Tenés 3 cosas para hoy.»; «Atrasadas»; «TP 2 · atrasado · Arquitectura de Computadoras · 21 oct 18:00»; «Hoy»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Próximas»; «Primer parcial · 25 oct 08:00»; «Informe de laboratorio · 28 oct 20:00»; «Sin fecha · Pedir apuntes a Belén».

DESKTOP 1440x900 WIREFRAME: Sidebar; lista Atrasadas/Hoy 600px, franja «Materia» 270px con enlace a correlativas verificadas solo desde una materia elegida.

MOBILE 390x844 WIREFRAME: 390: la acción «Ver materia» conduce a requisitos; no mapa ni bloque lateral.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: fecha → titular → atrasadas → hoy → próximas → sin fecha → cursando → final pendiente → avance.

ACCIÓN VISIBLE / CONTROLS: «Ver Análisis Matemático II» junto a Primer parcial; «Correlativas» solo en detalle si hay datos. Otras acciones reales relevantes: Marcar tarea hecha; Abrir materia; Ver calendario; Agregar fecha o tarea.

REALITY / FEASIBILITY: Contar 1 atrasada + 2 hoy = 3; Sin datos de productividad o cronómetro; No mostrar final fuera de horizonte 14 días. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S04-E · Primero lo urgente de hoy

**Layout desktop:** Hoja 730px con 1 atrasada y 2 del día abiertas; Próximas y Sin fecha visibles como secciones plegables con conteos; materias al final.

**Layout móvil:** 390: TP2, Teoría y TP4 dominan primer viewport; botón «Ver próximas 2» no oculta atraso. Primera vencida sobre fold; bottom tab + FAB sin pisar último renglón.

**Acción:** Cada grupo secundario tiene disclosure nativo y accesible; FAB Agregar sigue disponible. **Mejora:** Da decisión inmediata sin borrar datos que hoy-model ya agrupa.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S04-E, Hoy.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Sábado 24 de octubre»; «Tenés 3 cosas para hoy.»; «Atrasadas»; «TP 2 · atrasado · Arquitectura de Computadoras · 21 oct 18:00»; «Hoy»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Próximas»; «Primer parcial · 25 oct 08:00»; «Informe de laboratorio · 28 oct 20:00»; «Sin fecha · Pedir apuntes a Belén».

DESKTOP 1440x900 WIREFRAME: Hoja 730px con 1 atrasada y 2 del día abiertas; Próximas y Sin fecha visibles como secciones plegables con conteos; materias al final.

MOBILE 390x844 WIREFRAME: 390: TP2, Teoría y TP4 dominan primer viewport; botón «Ver próximas 2» no oculta atraso.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: fecha → titular → atrasadas → hoy → próximas → sin fecha → cursando → final pendiente → avance.

ACCIÓN VISIBLE / CONTROLS: Cada grupo secundario tiene disclosure nativo y accesible; FAB Agregar sigue disponible. Otras acciones reales relevantes: Marcar tarea hecha; Abrir materia; Ver calendario; Agregar fecha o tarea.

REALITY / FEASIBILITY: Contar 1 atrasada + 2 hoy = 3; Sin datos de productividad o cronómetro; No mostrar final fuera de horizonte 14 días. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S05 · Plan y correlativas

**Código real:** `src/routes/_app/plan.tsx`. **Problema UX:** Los años, estados, fuente y correlativas reales están disponibles pero cuesta reconocer por qué una materia está bloqueada.

#### S05-A · El plan, año por año

**Layout desktop:** Sidebar y columna 832px con nombre carrera, Plan 2023, fuente, barra discreta y capítulos 1.º/2.º año; estados en texto.

**Layout móvil:** 390: cada materia ocupa fila, estado debajo; explicación «Correlativas no publicadas» reemplaza métricas cuando aplica. Cada año en lista vertical; etiquetas Estado y Requiere legibles.

**Acción:** Fila abre detalle; «Cargar mi avance» tras encabezado del plan. **Mejora:** Conecta procedencia de plan con lista para reducir ambigüedad de estados.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S05-A, Plan y correlativas.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ingeniería en Sistemas de Información»; «Plan 2023»; «Fuente oficial»; «1.º año»; «2.º año»; «Análisis Matemático II»; «Cursando»; «Cargar mi avance»; «Correlativas no publicadas (estado alternativo)».

DESKTOP 1440x900 WIREFRAME: Sidebar y columna 832px con nombre carrera, Plan 2023, fuente, barra discreta y capítulos 1.º/2.º año; estados en texto.

MOBILE 390x844 WIREFRAME: 390: cada materia ocupa fila, estado debajo; explicación «Correlativas no publicadas» reemplaza métricas cuando aplica.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: carrera y plan → fuente → progreso sin cifra inventada → aviso de cobertura → años → materias → CTA avance.

ACCIÓN VISIBLE / CONTROLS: Fila abre detalle; «Cargar mi avance» tras encabezado del plan. Otras acciones reales relevantes: Abrir detalle de materia; Cambiar estado; Cargar avance; Abrir fuente oficial.

REALITY / FEASIBILITY: Estado alternativo: grafo desconocido, sin bloqueadas/habilitadas; Plan manual admite filas y alta manual; Fuente enlazada, no sello institucional. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S05-B · Plan como registro verificable

**Layout desktop:** Columna 860px con encabezados Materia/Estado/Requisitos dentro de cada año, fuente visible y filas 50px.

**Layout móvil:** 390: convertir columnas a dos líneas; «Requiere» mostrado debajo solo si conocido. Cada año en lista vertical; etiquetas Estado y Requiere legibles.

**Acción:** Selector de estado en línea y link oficial separado del título. **Mejora:** Se puede revisar de un vistazo qué está regularizado y qué falta sin reinterpretar estado.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S05-B, Plan y correlativas.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ingeniería en Sistemas de Información»; «Plan 2023»; «Fuente oficial»; «1.º año»; «2.º año»; «Análisis Matemático II»; «Cursando»; «Cargar mi avance»; «Correlativas no publicadas (estado alternativo)».

DESKTOP 1440x900 WIREFRAME: Columna 860px con encabezados Materia/Estado/Requisitos dentro de cada año, fuente visible y filas 50px.

MOBILE 390x844 WIREFRAME: 390: convertir columnas a dos líneas; «Requiere» mostrado debajo solo si conocido.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: carrera y plan → fuente → progreso sin cifra inventada → aviso de cobertura → años → materias → CTA avance.

ACCIÓN VISIBLE / CONTROLS: Selector de estado en línea y link oficial separado del título. Otras acciones reales relevantes: Abrir detalle de materia; Cambiar estado; Cargar avance; Abrir fuente oficial.

REALITY / FEASIBILITY: Estado alternativo: grafo desconocido, sin bloqueadas/habilitadas; Plan manual admite filas y alta manual; Fuente enlazada, no sello institucional. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S05-C · Materias con ficha de contexto

**Layout desktop:** Sidebar y grid 600+270px: años a izquierda, ficha de materia elegida a derecha con estado, Requiere, Habilita reales.

**Layout móvil:** 390: ficha se inserta debajo de materia seleccionada; sin rail fijo. Cada año en lista vertical; etiquetas Estado y Requiere legibles.

**Acción:** «Ver requisitos» abre ficha basada en materia real; fuente sigue arriba. **Mejora:** Acerca requisitos a la fila correspondiente, dejando claros los datos no publicados.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S05-C, Plan y correlativas.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ingeniería en Sistemas de Información»; «Plan 2023»; «Fuente oficial»; «1.º año»; «2.º año»; «Análisis Matemático II»; «Cursando»; «Cargar mi avance»; «Correlativas no publicadas (estado alternativo)».

DESKTOP 1440x900 WIREFRAME: Sidebar y grid 600+270px: años a izquierda, ficha de materia elegida a derecha con estado, Requiere, Habilita reales.

MOBILE 390x844 WIREFRAME: 390: ficha se inserta debajo de materia seleccionada; sin rail fijo.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: carrera y plan → fuente → progreso sin cifra inventada → aviso de cobertura → años → materias → CTA avance.

ACCIÓN VISIBLE / CONTROLS: «Ver requisitos» abre ficha basada en materia real; fuente sigue arriba. Otras acciones reales relevantes: Abrir detalle de materia; Cambiar estado; Cargar avance; Abrir fuente oficial.

REALITY / FEASIBILITY: Estado alternativo: grafo desconocido, sin bloqueadas/habilitadas; Plan manual admite filas y alta manual; Fuente enlazada, no sello institucional. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S05-D · Ruta de correlativas explicada

**Layout desktop:** Libro de años 400px y panel 470px de relación textual Requiere → materia → Habilita, solo si prerequisitesKnown.

**Layout móvil:** 390: una materia expandida y dos listas; sin líneas de grafo horizontal. Cada año en lista vertical; etiquetas Estado y Requiere legibles.

**Acción:** Fila «Análisis Matemático II» selecciona requisitos reales; fallback «No tenemos correlativas oficiales». **Mejora:** Responde «qué me falta para cursar» sin grafo especulativo ni habilitadas falsas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S05-D, Plan y correlativas.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ingeniería en Sistemas de Información»; «Plan 2023»; «Fuente oficial»; «1.º año»; «2.º año»; «Análisis Matemático II»; «Cursando»; «Cargar mi avance»; «Correlativas no publicadas (estado alternativo)».

DESKTOP 1440x900 WIREFRAME: Libro de años 400px y panel 470px de relación textual Requiere → materia → Habilita, solo si prerequisitesKnown.

MOBILE 390x844 WIREFRAME: 390: una materia expandida y dos listas; sin líneas de grafo horizontal.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: carrera y plan → fuente → progreso sin cifra inventada → aviso de cobertura → años → materias → CTA avance.

ACCIÓN VISIBLE / CONTROLS: Fila «Análisis Matemático II» selecciona requisitos reales; fallback «No tenemos correlativas oficiales». Otras acciones reales relevantes: Abrir detalle de materia; Cambiar estado; Cargar avance; Abrir fuente oficial.

REALITY / FEASIBILITY: Estado alternativo: grafo desconocido, sin bloqueadas/habilitadas; Plan manual admite filas y alta manual; Fuente enlazada, no sello institucional. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S05-E · Elegí el año que querés revisar

**Layout desktop:** Columna 730px con resumen plan/fuente/progreso, un año abierto y otros plegados con conteo de materias.

**Layout móvil:** 390: selector de año por encabezados apilados; se ve Cargar avance y estado desconocido sin desplegar. Cada año en lista vertical; etiquetas Estado y Requiere legibles.

**Acción:** Al abrir año, foco va al encabezado; cada fila sigue abriendo materia real. **Mejora:** Hace manejable un plan largo preservando la advertencia de falta de correlativas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S05-E, Plan y correlativas.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ingeniería en Sistemas de Información»; «Plan 2023»; «Fuente oficial»; «1.º año»; «2.º año»; «Análisis Matemático II»; «Cursando»; «Cargar mi avance»; «Correlativas no publicadas (estado alternativo)».

DESKTOP 1440x900 WIREFRAME: Columna 730px con resumen plan/fuente/progreso, un año abierto y otros plegados con conteo de materias.

MOBILE 390x844 WIREFRAME: 390: selector de año por encabezados apilados; se ve Cargar avance y estado desconocido sin desplegar.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: carrera y plan → fuente → progreso sin cifra inventada → aviso de cobertura → años → materias → CTA avance.

ACCIÓN VISIBLE / CONTROLS: Al abrir año, foco va al encabezado; cada fila sigue abriendo materia real. Otras acciones reales relevantes: Abrir detalle de materia; Cambiar estado; Cargar avance; Abrir fuente oficial.

REALITY / FEASIBILITY: Estado alternativo: grafo desconocido, sin bloqueadas/habilitadas; Plan manual admite filas y alta manual; Fuente enlazada, no sello institucional. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S06 · Materias lista

**Código real:** `src/routes/_app/courses.index.tsx`. **Problema UX:** Filtros con conteos, estados editables y cambio de vista conviven y pueden saturar la lista.

#### S06-A · Lista de materias sin ruido

**Layout desktop:** Columna de lectura 832px con filtros debajo del título, línea Lista/Tablero y filas serenas con nombre, año, estado.

**Layout móvil:** 390: chips wrap y estado bajo nombre; ninguna fila truncada por badge. Filtros con wrap, una fila por materia y estado multilínea.

**Acción:** Editar estado en línea, abrir materia tocando el nombre. **Mejora:** Evita que la edición de estado desplace la lectura de la materia elegida.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S06-A, Materias lista.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Todas»; «Cursando»; «Final pendiente»; «Análisis Matemático II · Cursando»; «Arquitectura de Computadoras · Regularizada»; «Lista»; «Tablero».

DESKTOP 1440x900 WIREFRAME: Columna de lectura 832px con filtros debajo del título, línea Lista/Tablero y filas serenas con nombre, año, estado.

MOBILE 390x844 WIREFRAME: 390: chips wrap y estado bajo nombre; ninguna fila truncada por badge.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → filtros → selector vista → lista → estado guardado.

ACCIÓN VISIBLE / CONTROLS: Editar estado en línea, abrir materia tocando el nombre. Otras acciones reales relevantes: Filtrar por estado; Alternar Lista/Tablero; Cambiar estado; Abrir materia.

REALITY / FEASIBILITY: Disponible solo si correlativas conocidas; Conservar fila recién modificada brevemente; Manual permite alta de materia. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S06-B · Materias para revisar rápido

**Layout desktop:** Lista 850px con contador en cada filtro y filas compactas Materia/Estado; fija fila alterada temporalmente.

**Layout móvil:** 390: filtro de estado ocupa líneas envolventes, fila de 48px + subtítulo. Filtros con wrap, una fila por materia y estado multilínea.

**Acción:** Filtro Cursando y cambio Estado conservan fila hasta confirmar guardado. **Mejora:** Mayor velocidad de lectura en plan grande respetando el pinning implementado.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S06-B, Materias lista.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Todas»; «Cursando»; «Final pendiente»; «Análisis Matemático II · Cursando»; «Arquitectura de Computadoras · Regularizada»; «Lista»; «Tablero».

DESKTOP 1440x900 WIREFRAME: Lista 850px con contador en cada filtro y filas compactas Materia/Estado; fija fila alterada temporalmente.

MOBILE 390x844 WIREFRAME: 390: filtro de estado ocupa líneas envolventes, fila de 48px + subtítulo.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → filtros → selector vista → lista → estado guardado.

ACCIÓN VISIBLE / CONTROLS: Filtro Cursando y cambio Estado conservan fila hasta confirmar guardado. Otras acciones reales relevantes: Filtrar por estado; Alternar Lista/Tablero; Cambiar estado; Abrir materia.

REALITY / FEASIBILITY: Disponible solo si correlativas conocidas; Conservar fila recién modificada brevemente; Manual permite alta de materia. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S06-C · Lista y estado académico

**Layout desktop:** Grid 600+270px: listado filtrado a izquierda, ficha derecha de estado/avance de materia seleccionada disponible en el dominio.

**Layout móvil:** 390: ficha del estado bajo la fila activa; resto mantiene lista. Filtros con wrap, una fila por materia y estado multilínea.

**Acción:** Al seleccionar fila, mostrar contexto y control de estado real. **Mejora:** Da explicación de «Regularizada» al editar sin crear una vista de proyectos.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S06-C, Materias lista.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Todas»; «Cursando»; «Final pendiente»; «Análisis Matemático II · Cursando»; «Arquitectura de Computadoras · Regularizada»; «Lista»; «Tablero».

DESKTOP 1440x900 WIREFRAME: Grid 600+270px: listado filtrado a izquierda, ficha derecha de estado/avance de materia seleccionada disponible en el dominio.

MOBILE 390x844 WIREFRAME: 390: ficha del estado bajo la fila activa; resto mantiene lista.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → filtros → selector vista → lista → estado guardado.

ACCIÓN VISIBLE / CONTROLS: Al seleccionar fila, mostrar contexto y control de estado real. Otras acciones reales relevantes: Filtrar por estado; Alternar Lista/Tablero; Cambiar estado; Abrir materia.

REALITY / FEASIBILITY: Disponible solo si correlativas conocidas; Conservar fila recién modificada brevemente; Manual permite alta de materia. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S06-D · Materias dentro de sus años

**Layout desktop:** Lista agrupada por año con pequeñas relaciones Requiere/Habilita solo para materia con grafo conocido; filtros existentes arriba.

**Layout móvil:** 390: lista por años, detalle de correlativas al abrir materia, nunca mapa miniatura. Filtros con wrap, una fila por materia y estado multilínea.

**Acción:** Enlace «Ver correlativas» dirige a detalle, no acción falsa dentro del listado. **Mejora:** Conecta filtro de cursada con plan oficial y evita llamar disponible a lo desconocido.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S06-D, Materias lista.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Todas»; «Cursando»; «Final pendiente»; «Análisis Matemático II · Cursando»; «Arquitectura de Computadoras · Regularizada»; «Lista»; «Tablero».

DESKTOP 1440x900 WIREFRAME: Lista agrupada por año con pequeñas relaciones Requiere/Habilita solo para materia con grafo conocido; filtros existentes arriba.

MOBILE 390x844 WIREFRAME: 390: lista por años, detalle de correlativas al abrir materia, nunca mapa miniatura.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → filtros → selector vista → lista → estado guardado.

ACCIÓN VISIBLE / CONTROLS: Enlace «Ver correlativas» dirige a detalle, no acción falsa dentro del listado. Otras acciones reales relevantes: Filtrar por estado; Alternar Lista/Tablero; Cambiar estado; Abrir materia.

REALITY / FEASIBILITY: Disponible solo si correlativas conocidas; Conservar fila recién modificada brevemente; Manual permite alta de materia. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S06-E · Primero, tus materias en curso

**Layout desktop:** Filas de Cursando abiertas, demás filtros visibles en una banda; conteo si está disponible; selector Lista/Tablero discreto.

**Layout móvil:** 390: chip Cursando seleccionado, Todas al lado; se puede cambiar filtro sin ocultarlo. Filtros con wrap, una fila por materia y estado multilínea.

**Acción:** Pulsar Todas reconstruye la lista; cambiando estado se mantiene feedback temporal. **Mejora:** Reduce decisiones iniciales y ofrece salida rápida a todas las materias sin forzar default real.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S06-E, Materias lista.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Todas»; «Cursando»; «Final pendiente»; «Análisis Matemático II · Cursando»; «Arquitectura de Computadoras · Regularizada»; «Lista»; «Tablero».

DESKTOP 1440x900 WIREFRAME: Filas de Cursando abiertas, demás filtros visibles en una banda; conteo si está disponible; selector Lista/Tablero discreto.

MOBILE 390x844 WIREFRAME: 390: chip Cursando seleccionado, Todas al lado; se puede cambiar filtro sin ocultarlo.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → filtros → selector vista → lista → estado guardado.

ACCIÓN VISIBLE / CONTROLS: Pulsar Todas reconstruye la lista; cambiando estado se mantiene feedback temporal. Otras acciones reales relevantes: Filtrar por estado; Alternar Lista/Tablero; Cambiar estado; Abrir materia.

REALITY / FEASIBILITY: Disponible solo si correlativas conocidas; Conservar fila recién modificada brevemente; Manual permite alta de materia. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S07 · Materias tablero

**Código real:** `src/features/courses/subject-board-view.tsx`. **Problema UX:** Las columnas por estado pueden estrechar nombres y sugerir drag-and-drop no disponible.

#### S07-A · Tablero académico por estados

**Layout desktop:** Canvas tras sidebar en columnas de estado definidas, títulos Newsreader pequeños y fichas lineales sin sombras ni handle.

**Layout móvil:** 390: secciones apiladas Cursando/Final pendiente/Aprobadas con control de estado debajo de cada nombre. Columnas académicas apiladas o una por pestaña; sin drag.

**Acción:** Cambiar estado mediante selector real, no arrastrando la tarjeta. **Mejora:** Evita que una disposición tipo Trello haga creer que hay drag de materias.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S07-A, Materias tablero.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Tablero»; «Cursando»; «Final pendiente»; «Aprobadas»; «Análisis Matemático II»; «Física II»; «Arquitectura de Computadoras».

DESKTOP 1440x900 WIREFRAME: Canvas tras sidebar en columnas de estado definidas, títulos Newsreader pequeños y fichas lineales sin sombras ni handle.

MOBILE 390x844 WIREFRAME: 390: secciones apiladas Cursando/Final pendiente/Aprobadas con control de estado debajo de cada nombre.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → filtros → selector vista → columnas por estado → feedback.

ACCIÓN VISIBLE / CONTROLS: Cambiar estado mediante selector real, no arrastrando la tarjeta. Otras acciones reales relevantes: Filtrar estado; Cambiar a Lista; Abrir materia; Actualizar estado mediante control.

REALITY / FEASIBILITY: No pintar tarjetas arrastrables; No inventar tareas sprint; Disponible solo con grafo oficial. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S07-B · Columnas compactas de seguimiento

**Layout desktop:** Kanban 3–4 columnas de ancho ≥240px, cabecera con contador de materias y filas 48px.

**Layout móvil:** 390: una columna por vez elegida mediante pestañas de estado, o secciones verticales si accesibilidad exige. Columnas académicas apiladas o una por pestaña; sin drag.

**Acción:** Cada columna posee enlace a materia y status control; «Lista» restaura lista. **Mejora:** Aprovecha tablero existente y conserva contadores legibles sin overflow de tarjetas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S07-B, Materias tablero.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Tablero»; «Cursando»; «Final pendiente»; «Aprobadas»; «Análisis Matemático II»; «Física II»; «Arquitectura de Computadoras».

DESKTOP 1440x900 WIREFRAME: Kanban 3–4 columnas de ancho ≥240px, cabecera con contador de materias y filas 48px.

MOBILE 390x844 WIREFRAME: 390: una columna por vez elegida mediante pestañas de estado, o secciones verticales si accesibilidad exige.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → filtros → selector vista → columnas por estado → feedback.

ACCIÓN VISIBLE / CONTROLS: Cada columna posee enlace a materia y status control; «Lista» restaura lista. Otras acciones reales relevantes: Filtrar estado; Cambiar a Lista; Abrir materia; Actualizar estado mediante control.

REALITY / FEASIBILITY: No pintar tarjetas arrastrables; No inventar tareas sprint; Disponible solo con grafo oficial. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S07-C · Tablero y definición de estado

**Layout desktop:** Tablero ocupa 75% de canvas, ayuda lateral 240px explica estado de columna activa sin KPI.

**Layout móvil:** 390: ayuda bajo encabezado de columna activa, sin panel lateral. Columnas académicas apiladas o una por pestaña; sin drag.

**Acción:** En encabezado «Final pendiente» enlace «¿Qué significa?» abre explicación. **Mejora:** Explica diferencia Final pendiente frente Aprobada donde el tablero induce más errores.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S07-C, Materias tablero.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Tablero»; «Cursando»; «Final pendiente»; «Aprobadas»; «Análisis Matemático II»; «Física II»; «Arquitectura de Computadoras».

DESKTOP 1440x900 WIREFRAME: Tablero ocupa 75% de canvas, ayuda lateral 240px explica estado de columna activa sin KPI.

MOBILE 390x844 WIREFRAME: 390: ayuda bajo encabezado de columna activa, sin panel lateral.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → filtros → selector vista → columnas por estado → feedback.

ACCIÓN VISIBLE / CONTROLS: En encabezado «Final pendiente» enlace «¿Qué significa?» abre explicación. Otras acciones reales relevantes: Filtrar estado; Cambiar a Lista; Abrir materia; Actualizar estado mediante control.

REALITY / FEASIBILITY: No pintar tarjetas arrastrables; No inventar tareas sprint; Disponible solo con grafo oficial. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S07-D · Estados como trayectoria, sin arrastre

**Layout desktop:** Bandas horizontales Cursando → Regularizada → Aprobada etiquetadas, tarjetas enlazan detalle; ningún cambio por drag.

**Layout móvil:** 390: bandas convertidas en lista, flechas solo indican lectura conceptual, no conversión automática. Columnas académicas apiladas o una por pestaña; sin drag.

**Acción:** Botón «Cambiar estado» en cada tarjeta abre control real. **Mejora:** Evita presentar un flujo de estado automático donde el código requiere selección deliberada.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S07-D, Materias tablero.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Tablero»; «Cursando»; «Final pendiente»; «Aprobadas»; «Análisis Matemático II»; «Física II»; «Arquitectura de Computadoras».

DESKTOP 1440x900 WIREFRAME: Bandas horizontales Cursando → Regularizada → Aprobada etiquetadas, tarjetas enlazan detalle; ningún cambio por drag.

MOBILE 390x844 WIREFRAME: 390: bandas convertidas en lista, flechas solo indican lectura conceptual, no conversión automática.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → filtros → selector vista → columnas por estado → feedback.

ACCIÓN VISIBLE / CONTROLS: Botón «Cambiar estado» en cada tarjeta abre control real. Otras acciones reales relevantes: Filtrar estado; Cambiar a Lista; Abrir materia; Actualizar estado mediante control.

REALITY / FEASIBILITY: No pintar tarjetas arrastrables; No inventar tareas sprint; Disponible solo con grafo oficial. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S07-E · Un estado académico por vez

**Layout desktop:** Tablero compacto con columna Cursando priorizada y los otros encabezados desplegables con cantidades conocidas.

**Layout móvil:** 390: primera columna desplegada y acceso persistente a Final pendiente y Aprobadas. Columnas académicas apiladas o una por pestaña; sin drag.

**Acción:** Expandir categoría muestra materias y control; selector Lista siempre visible. **Mejora:** Reduce el largo del tablero en móvil y permite evaluar concentración sin perder categorías.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S07-E, Materias tablero.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus materias»; «Tablero»; «Cursando»; «Final pendiente»; «Aprobadas»; «Análisis Matemático II»; «Física II»; «Arquitectura de Computadoras».

DESKTOP 1440x900 WIREFRAME: Tablero compacto con columna Cursando priorizada y los otros encabezados desplegables con cantidades conocidas.

MOBILE 390x844 WIREFRAME: 390: primera columna desplegada y acceso persistente a Final pendiente y Aprobadas.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: título → filtros → selector vista → columnas por estado → feedback.

ACCIÓN VISIBLE / CONTROLS: Expandir categoría muestra materias y control; selector Lista siempre visible. Otras acciones reales relevantes: Filtrar estado; Cambiar a Lista; Abrir materia; Actualizar estado mediante control.

REALITY / FEASIBILITY: No pintar tarjetas arrastrables; No inventar tareas sprint; Disponible solo con grafo oficial. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S08 · Detalle de materia

**Código real:** `src/routes/_app/courses.$courseId.tsx`, `src/features/courses/subject-notes.tsx`. **Problema UX:** Fechas, estado, material y correlativas compiten por prioridad en una misma lectura.

#### S08-A · Una materia, todos sus vínculos

**Layout desktop:** Columna 860px, volver, título Análisis Matemático II + Cursando, sección próxima fecha, Fechas, Notas local, Correlativas y Material.

**Layout móvil:** 390: botón Agregar entrega bajo estado, fechas primero; títulos de secciones en filetes. Título largo ocupa 2 líneas, CTA propia bajo título; sin segundo FAB.

**Acción:** Agregar entrega abre modal con materia preasociada; links abren detalle existente. **Mejora:** Prioriza parcial real antes de enlaces y mejora lectura sin añadir pestañas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S08-A, Detalle de materia.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Volver a materias»; «Análisis Matemático II»; «Cursando»; «Primer parcial · 25 oct · 08:00»; «Fechas»; «Correlativas»; «Requiere»; «Habilita»; «Material»; «Agregar entrega».

DESKTOP 1440x900 WIREFRAME: Columna 860px, volver, título Análisis Matemático II + Cursando, sección próxima fecha, Fechas, Notas local, Correlativas y Material.

MOBILE 390x844 WIREFRAME: 390: botón Agregar entrega bajo estado, fechas primero; títulos de secciones en filetes.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → materia/estado → fecha próxima → fechas → notas disponibles → correlativas verificadas → material.

ACCIÓN VISIBLE / CONTROLS: Agregar entrega abre modal con materia preasociada; links abren detalle existente. Otras acciones reales relevantes: Agregar entrega preasociada; Cambiar estado; Abrir correlativa; Abrir recurso; Ir a nota local cuando exista.

REALITY / FEASIBILITY: Notas solo en carpeta local; Correlativas desconocidas: aviso, sin relaciones; No prometer pestañas/scroll spy inexistentes. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S08-B · Ficha de materia compacta

**Layout desktop:** Cabecera de 2 líneas con metadatos año/estado, tabla de fechas 2 columnas, requisites/material como listas compactas.

**Layout móvil:** 390: fecha y tipo se apilan, estado junto al nombre sin taparlo. Título largo ocupa 2 líneas, CTA propia bajo título; sin segundo FAB.

**Acción:** Control Cursando editable y CTA de agregar alineado a fechas. **Mejora:** Hace visible fecha del parcial y estado de cursada en el mismo primer vistazo.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S08-B, Detalle de materia.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Volver a materias»; «Análisis Matemático II»; «Cursando»; «Primer parcial · 25 oct · 08:00»; «Fechas»; «Correlativas»; «Requiere»; «Habilita»; «Material»; «Agregar entrega».

DESKTOP 1440x900 WIREFRAME: Cabecera de 2 líneas con metadatos año/estado, tabla de fechas 2 columnas, requisites/material como listas compactas.

MOBILE 390x844 WIREFRAME: 390: fecha y tipo se apilan, estado junto al nombre sin taparlo.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → materia/estado → fecha próxima → fechas → notas disponibles → correlativas verificadas → material.

ACCIÓN VISIBLE / CONTROLS: Control Cursando editable y CTA de agregar alineado a fechas. Otras acciones reales relevantes: Agregar entrega preasociada; Cambiar estado; Abrir correlativa; Abrir recurso; Ir a nota local cuando exista.

REALITY / FEASIBILITY: Notas solo en carpeta local; Correlativas desconocidas: aviso, sin relaciones; No prometer pestañas/scroll spy inexistentes. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S08-C · Materia y próxima entrega

**Layout desktop:** Zona 600px para Fechas/Material y lateral 270px para estado/Requiere/Habilita real, cuando hay datos.

**Layout móvil:** 390: estado y próxima fecha antes de secciones, correlativas abajo, sin rail. Título largo ocupa 2 líneas, CTA propia bajo título; sin segundo FAB.

**Acción:** «Ver correlativa» navega a otra materia; acciones de Material en su bloque. **Mejora:** Mantiene lectura de obligaciones mientras conecta el origen académico de la materia.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S08-C, Detalle de materia.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Volver a materias»; «Análisis Matemático II»; «Cursando»; «Primer parcial · 25 oct · 08:00»; «Fechas»; «Correlativas»; «Requiere»; «Habilita»; «Material»; «Agregar entrega».

DESKTOP 1440x900 WIREFRAME: Zona 600px para Fechas/Material y lateral 270px para estado/Requiere/Habilita real, cuando hay datos.

MOBILE 390x844 WIREFRAME: 390: estado y próxima fecha antes de secciones, correlativas abajo, sin rail.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → materia/estado → fecha próxima → fechas → notas disponibles → correlativas verificadas → material.

ACCIÓN VISIBLE / CONTROLS: «Ver correlativa» navega a otra materia; acciones de Material en su bloque. Otras acciones reales relevantes: Agregar entrega preasociada; Cambiar estado; Abrir correlativa; Abrir recurso; Ir a nota local cuando exista.

REALITY / FEASIBILITY: Notas solo en carpeta local; Correlativas desconocidas: aviso, sin relaciones; No prometer pestañas/scroll spy inexistentes. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S08-D · Requisitos en contexto

**Layout desktop:** Encabezado y dos zonas: Fechas 400px; lista textual Requiere y Habilita 440px, solo si plan lo publica.

**Layout móvil:** 390: Requiere/Habilita detrás del detalle de fechas, sin representación gráfica. Título largo ocupa 2 líneas, CTA propia bajo título; sin segundo FAB.

**Acción:** Cada materia relacionada es un enlace real a su detalle, sin simulación de nodos. **Mejora:** Hace visibles relaciones oficiales y evita falso bloqueo con grafo ausente.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S08-D, Detalle de materia.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Volver a materias»; «Análisis Matemático II»; «Cursando»; «Primer parcial · 25 oct · 08:00»; «Fechas»; «Correlativas»; «Requiere»; «Habilita»; «Material»; «Agregar entrega».

DESKTOP 1440x900 WIREFRAME: Encabezado y dos zonas: Fechas 400px; lista textual Requiere y Habilita 440px, solo si plan lo publica.

MOBILE 390x844 WIREFRAME: 390: Requiere/Habilita detrás del detalle de fechas, sin representación gráfica.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → materia/estado → fecha próxima → fechas → notas disponibles → correlativas verificadas → material.

ACCIÓN VISIBLE / CONTROLS: Cada materia relacionada es un enlace real a su detalle, sin simulación de nodos. Otras acciones reales relevantes: Agregar entrega preasociada; Cambiar estado; Abrir correlativa; Abrir recurso; Ir a nota local cuando exista.

REALITY / FEASIBILITY: Notas solo en carpeta local; Correlativas desconocidas: aviso, sin relaciones; No prometer pestañas/scroll spy inexistentes. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S08-E · Prepará el próximo parcial

**Layout desktop:** Primer bloque 730px con «Primer parcial · 25 oct · 08:00» y Agregar entrega; Fechas/Material/Correlativas como secciones expandibles etiquetadas.

**Layout móvil:** 390: título + próxima fecha ocupan primera pantalla; No ocultar estado académico. Título largo ocupa 2 líneas, CTA propia bajo título; sin segundo FAB.

**Acción:** Desplegar «Ver correlativas» solo cuando exista; acción Material mantiene enlace directo. **Mejora:** Ayuda a encontrar el siguiente paso y conserva el acceso a resto de la materia.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S08-E, Detalle de materia.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Volver a materias»; «Análisis Matemático II»; «Cursando»; «Primer parcial · 25 oct · 08:00»; «Fechas»; «Correlativas»; «Requiere»; «Habilita»; «Material»; «Agregar entrega».

DESKTOP 1440x900 WIREFRAME: Primer bloque 730px con «Primer parcial · 25 oct · 08:00» y Agregar entrega; Fechas/Material/Correlativas como secciones expandibles etiquetadas.

MOBILE 390x844 WIREFRAME: 390: título + próxima fecha ocupan primera pantalla; No ocultar estado académico.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: volver → materia/estado → fecha próxima → fechas → notas disponibles → correlativas verificadas → material.

ACCIÓN VISIBLE / CONTROLS: Desplegar «Ver correlativas» solo cuando exista; acción Material mantiene enlace directo. Otras acciones reales relevantes: Agregar entrega preasociada; Cambiar estado; Abrir correlativa; Abrir recurso; Ir a nota local cuando exista.

REALITY / FEASIBILITY: Notas solo en carpeta local; Correlativas desconocidas: aviso, sin relaciones; No prometer pestañas/scroll spy inexistentes. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S09 · Calendario mes

**Código real:** `src/features/calendar/campus-calendar.tsx`. **Problema UX:** La grilla mensual llena el canvas; los chips necesitan texto y semántica al desbordar el día.

#### S09-A · Octubre como página de cuaderno

**Layout desktop:** Canvas full-bleed y grilla 7 días de líneas finas; arriba Octubre 2026 y Mes/Semana/Agenda; eventos chips textuales.

**Layout móvil:** 390: números de día grandes, puntos con conteo y texto recortado solo con acceso a evento/agenda. Mes en 7 celdas compactas con resumen y acceso a agenda.

**Acción:** Botones anterior/siguiente y Hoy; clic de chip abre evento, sin drag. **Mejora:** Reduce el ruido de cuadrícula sin perder clases, parciales o materias.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S09-A, Calendario mes.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Mes»; «Semana»; «Agenda»; «Hoy»; «TP 2 · atrasado · 21 oct»; «Teoría · 24 oct»; «TP 4 · entrega · 24 oct»; «Primer parcial · 25 oct»; «Informe de laboratorio · 28 oct».

DESKTOP 1440x900 WIREFRAME: Canvas full-bleed y grilla 7 días de líneas finas; arriba Octubre 2026 y Mes/Semana/Agenda; eventos chips textuales.

MOBILE 390x844 WIREFRAME: 390: números de día grandes, puntos con conteo y texto recortado solo con acceso a evento/agenda.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: mes/navegación → selector vistas → grilla 7 columnas → chips de materia → sin fecha si aplica.

ACCIÓN VISIBLE / CONTROLS: Botones anterior/siguiente y Hoy; clic de chip abre evento, sin drag. Otras acciones reales relevantes: Ir a hoy; Mes anterior/siguiente; Cambiar a Semana/Agenda; Abrir evento.

REALITY / FEASIBILITY: Semana empieza lunes; Eventos no son arrastrables; Colores de materias siempre acompañados de texto. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S09-B · Mes de alta legibilidad

**Layout desktop:** Header compacto, columnas de días con 2 líneas máximo por chip, fecha tabular e indicador de más eventos.

**Layout móvil:** 390: mini-celdas con fecha + cuenta; pasar a Agenda desde selector para texto completo. Mes en 7 celdas compactas con resumen y acceso a agenda.

**Acción:** Control Mes activo y switch Semana/Agenda; los eventos abren detalle. **Mejora:** Facilita ubicar TP2 del 21, TP4 del 24 y parcial del 25 rápidamente.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S09-B, Calendario mes.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Mes»; «Semana»; «Agenda»; «Hoy»; «TP 2 · atrasado · 21 oct»; «Teoría · 24 oct»; «TP 4 · entrega · 24 oct»; «Primer parcial · 25 oct»; «Informe de laboratorio · 28 oct».

DESKTOP 1440x900 WIREFRAME: Header compacto, columnas de días con 2 líneas máximo por chip, fecha tabular e indicador de más eventos.

MOBILE 390x844 WIREFRAME: 390: mini-celdas con fecha + cuenta; pasar a Agenda desde selector para texto completo.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: mes/navegación → selector vistas → grilla 7 columnas → chips de materia → sin fecha si aplica.

ACCIÓN VISIBLE / CONTROLS: Control Mes activo y switch Semana/Agenda; los eventos abren detalle. Otras acciones reales relevantes: Ir a hoy; Mes anterior/siguiente; Cambiar a Semana/Agenda; Abrir evento.

REALITY / FEASIBILITY: Semana empieza lunes; Eventos no son arrastrables; Colores de materias siempre acompañados de texto. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S09-C · Calendario y contexto de día

**Layout desktop:** Grilla mes usa 75% del canvas; panel derecha 250px detalla obligaciones del día seleccionado usando mismo evento.

**Layout móvil:** 390: detalle del día se apila bajo grilla, no rail, con acción de abrir evento. Mes en 7 celdas compactas con resumen y acceso a agenda.

**Acción:** Seleccionar día muestra eventos de ese día, selección FUTURO explícita. **Mejora:** Aclara chips truncados mediante detalle real sin inventar calendario nuevo.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S09-C, Calendario mes.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Mes»; «Semana»; «Agenda»; «Hoy»; «TP 2 · atrasado · 21 oct»; «Teoría · 24 oct»; «TP 4 · entrega · 24 oct»; «Primer parcial · 25 oct»; «Informe de laboratorio · 28 oct».

DESKTOP 1440x900 WIREFRAME: Grilla mes usa 75% del canvas; panel derecha 250px detalla obligaciones del día seleccionado usando mismo evento.

MOBILE 390x844 WIREFRAME: 390: detalle del día se apila bajo grilla, no rail, con acción de abrir evento.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: mes/navegación → selector vistas → grilla 7 columnas → chips de materia → sin fecha si aplica.

ACCIÓN VISIBLE / CONTROLS: Seleccionar día muestra eventos de ese día, selección FUTURO explícita. Otras acciones reales relevantes: Ir a hoy; Mes anterior/siguiente; Cambiar a Semana/Agenda; Abrir evento.

REALITY / FEASIBILITY: Semana empieza lunes; Eventos no son arrastrables; Colores de materias siempre acompañados de texto. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S09-D · Mes ligado a materias

**Layout desktop:** Grilla normal más lista inferior de materias asociadas a chips seleccionados; vínculos a sus detalles reales.

**Layout móvil:** 390: desde chip abrir ficha del evento y materia; nada de conexiones cruzando celdas. Mes en 7 celdas compactas con resumen y acceso a agenda.

**Acción:** «Ver materia» solo dentro de detalle de evento existente. **Mejora:** Explica qué asignatura corresponde a cada fecha al perderse el nombre en móvil.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S09-D, Calendario mes.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Mes»; «Semana»; «Agenda»; «Hoy»; «TP 2 · atrasado · 21 oct»; «Teoría · 24 oct»; «TP 4 · entrega · 24 oct»; «Primer parcial · 25 oct»; «Informe de laboratorio · 28 oct».

DESKTOP 1440x900 WIREFRAME: Grilla normal más lista inferior de materias asociadas a chips seleccionados; vínculos a sus detalles reales.

MOBILE 390x844 WIREFRAME: 390: desde chip abrir ficha del evento y materia; nada de conexiones cruzando celdas.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: mes/navegación → selector vistas → grilla 7 columnas → chips de materia → sin fecha si aplica.

ACCIÓN VISIBLE / CONTROLS: «Ver materia» solo dentro de detalle de evento existente. Otras acciones reales relevantes: Ir a hoy; Mes anterior/siguiente; Cambiar a Semana/Agenda; Abrir evento.

REALITY / FEASIBILITY: Semana empieza lunes; Eventos no son arrastrables; Colores de materias siempre acompañados de texto. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S09-E · Lo próximo dentro del mes

**Layout desktop:** Grilla del mes íntegra con hoy marcado; bloque de detalle de día activo claro y discreto; controles de vista siempre presentes.

**Layout móvil:** 390: mes simplificado con evento más cercano señalado; Agenda accesible desde primer renglón. Mes en 7 celdas compactas con resumen y acceso a agenda.

**Acción:** Tocar fecha revela lista de eventos en un bloque propuesto, sin edición drag. **Mejora:** Da lectura del mes sin hacer que un chip pequeño sea única pista de vencimiento.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S09-E, Calendario mes.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Mes»; «Semana»; «Agenda»; «Hoy»; «TP 2 · atrasado · 21 oct»; «Teoría · 24 oct»; «TP 4 · entrega · 24 oct»; «Primer parcial · 25 oct»; «Informe de laboratorio · 28 oct».

DESKTOP 1440x900 WIREFRAME: Grilla del mes íntegra con hoy marcado; bloque de detalle de día activo claro y discreto; controles de vista siempre presentes.

MOBILE 390x844 WIREFRAME: 390: mes simplificado con evento más cercano señalado; Agenda accesible desde primer renglón.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: mes/navegación → selector vistas → grilla 7 columnas → chips de materia → sin fecha si aplica.

ACCIÓN VISIBLE / CONTROLS: Tocar fecha revela lista de eventos en un bloque propuesto, sin edición drag. Otras acciones reales relevantes: Ir a hoy; Mes anterior/siguiente; Cambiar a Semana/Agenda; Abrir evento.

REALITY / FEASIBILITY: Semana empieza lunes; Eventos no son arrastrables; Colores de materias siempre acompañados de texto. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S10 · Calendario semana

**Código real:** `src/features/calendar/campus-calendar.tsx`. **Problema UX:** El eje de días y horas se comprime a 768 y los eventos todo el día no deben adquirir horario ficticio.

#### S10-A · Semana con aire y horas reales

**Layout desktop:** Canvas semanal con 7 columnas, cabecera por día, eje horario y banda todo el día; etiquetas claras en eventos 09:00/18:00.

**Layout móvil:** 390: fila de 7 días en pestañas; agenda horaria del día bajo selector, sin grilla microscópica. Selector de día en semana y agenda del día, sin pintar cuadrícula ilegible.

**Acción:** Botones Semana anterior/siguiente + ver detalle; deshabilitar arrastrar. **Mejora:** Evita confundir evento todo el día y uno con hora en cambio tablet/desktop.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 768x1024; one screen only, no device mockup or split before/after comparison. Screen ID S10-A, Calendario semana.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «19–25 de octubre de 2026»; «Semana»; «Lun 19»; «Mié 21»; «Sáb 24»; «Dom 25»; «TP 2 · atrasado · 18:00»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Primer parcial · 08:00».

DESKTOP 1440x900 WIREFRAME: Canvas semanal con 7 columnas, cabecera por día, eje horario y banda todo el día; etiquetas claras en eventos 09:00/18:00.

MOBILE 390x844 WIREFRAME: 390: fila de 7 días en pestañas; agenda horaria del día bajo selector, sin grilla microscópica.

Muestra el viewport solicitado 768x1024 con esta estructura y priorización: rango/navegación → selector modo → fila todo el día → eje horario → eventos.

ACCIÓN VISIBLE / CONTROLS: Botones Semana anterior/siguiente + ver detalle; deshabilitar arrastrar. Otras acciones reales relevantes: Semana anterior/siguiente; Hoy; Cambiar a Mes/Agenda; Abrir evento.

REALITY / FEASIBILITY: Hora real solo si fixture la tiene; Sin drag ni resize de evento; No duplicar Informe 28/10 fuera de semana. Sidebar real 220px desde md; lienzo restante 548px brutos; sin nav inferior. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S10-B · Horario por columnas

**Layout desktop:** Grilla 7 días con marcas horarias tabulares, eventos compactos por tipo/materia y bloques sin hora separados.

**Layout móvil:** 390: agenda semanal de columnas Día/Hora/Título convertida a filas por día. Selector de día en semana y agenda del día, sin pintar cuadrícula ilegible.

**Acción:** Cambiar a Agenda cuando no entre el nombre completo; selector persiste visible. **Mejora:** Acelera comparar Teoría 09:00 y TP4 18:00 del sábado con parcial 08:00 del domingo.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 768x1024; one screen only, no device mockup or split before/after comparison. Screen ID S10-B, Calendario semana.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «19–25 de octubre de 2026»; «Semana»; «Lun 19»; «Mié 21»; «Sáb 24»; «Dom 25»; «TP 2 · atrasado · 18:00»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Primer parcial · 08:00».

DESKTOP 1440x900 WIREFRAME: Grilla 7 días con marcas horarias tabulares, eventos compactos por tipo/materia y bloques sin hora separados.

MOBILE 390x844 WIREFRAME: 390: agenda semanal de columnas Día/Hora/Título convertida a filas por día.

Muestra el viewport solicitado 768x1024 con esta estructura y priorización: rango/navegación → selector modo → fila todo el día → eje horario → eventos.

ACCIÓN VISIBLE / CONTROLS: Cambiar a Agenda cuando no entre el nombre completo; selector persiste visible. Otras acciones reales relevantes: Semana anterior/siguiente; Hoy; Cambiar a Mes/Agenda; Abrir evento.

REALITY / FEASIBILITY: Hora real solo si fixture la tiene; Sin drag ni resize de evento; No duplicar Informe 28/10 fuera de semana. Sidebar real 220px desde md; lienzo restante 548px brutos; sin nav inferior. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S10-C · Semana más día elegido

**Layout desktop:** Semana 70% canvas, derecha 260px lista del día seleccionado con hora, tipo y materia existentes.

**Layout móvil:** 390: listado de día bajo selector de fecha; ningún panel lateral fijo. Selector de día en semana y agenda del día, sin pintar cuadrícula ilegible.

**Acción:** Tocar día abre sus eventos con vínculos; selección de día FUTURO. **Mejora:** Evita que etiquetas estrechas oculten el nombre del parcial y su materia.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 768x1024; one screen only, no device mockup or split before/after comparison. Screen ID S10-C, Calendario semana.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «19–25 de octubre de 2026»; «Semana»; «Lun 19»; «Mié 21»; «Sáb 24»; «Dom 25»; «TP 2 · atrasado · 18:00»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Primer parcial · 08:00».

DESKTOP 1440x900 WIREFRAME: Semana 70% canvas, derecha 260px lista del día seleccionado con hora, tipo y materia existentes.

MOBILE 390x844 WIREFRAME: 390: listado de día bajo selector de fecha; ningún panel lateral fijo.

Muestra el viewport solicitado 768x1024 con esta estructura y priorización: rango/navegación → selector modo → fila todo el día → eje horario → eventos.

ACCIÓN VISIBLE / CONTROLS: Tocar día abre sus eventos con vínculos; selección de día FUTURO. Otras acciones reales relevantes: Semana anterior/siguiente; Hoy; Cambiar a Mes/Agenda; Abrir evento.

REALITY / FEASIBILITY: Hora real solo si fixture la tiene; Sin drag ni resize de evento; No duplicar Informe 28/10 fuera de semana. Sidebar real 220px desde md; lienzo restante 548px brutos; sin nav inferior. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S10-D · Semana anclada a materia

**Layout desktop:** Eje semanal con eventos reales y panel abajo «Materias de esta semana» derivado de los mismos eventos, sin fechas extra.

**Layout móvil:** 390: alternar entre día y lista de materias vinculadas; no grafo. Selector de día en semana y agenda del día, sin pintar cuadrícula ilegible.

**Acción:** Evento abre detalle y enlace a materia; sin reprogramar por arrastre. **Mejora:** Facilita pasar de evento a su materia manteniendo el calendario como fuente.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 768x1024; one screen only, no device mockup or split before/after comparison. Screen ID S10-D, Calendario semana.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «19–25 de octubre de 2026»; «Semana»; «Lun 19»; «Mié 21»; «Sáb 24»; «Dom 25»; «TP 2 · atrasado · 18:00»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Primer parcial · 08:00».

DESKTOP 1440x900 WIREFRAME: Eje semanal con eventos reales y panel abajo «Materias de esta semana» derivado de los mismos eventos, sin fechas extra.

MOBILE 390x844 WIREFRAME: 390: alternar entre día y lista de materias vinculadas; no grafo.

Muestra el viewport solicitado 768x1024 con esta estructura y priorización: rango/navegación → selector modo → fila todo el día → eje horario → eventos.

ACCIÓN VISIBLE / CONTROLS: Evento abre detalle y enlace a materia; sin reprogramar por arrastre. Otras acciones reales relevantes: Semana anterior/siguiente; Hoy; Cambiar a Mes/Agenda; Abrir evento.

REALITY / FEASIBILITY: Hora real solo si fixture la tiene; Sin drag ni resize de evento; No duplicar Informe 28/10 fuera de semana. Sidebar real 220px desde md; lienzo restante 548px brutos; sin nav inferior. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S10-E · Elegí el día, mirá su agenda

**Layout desktop:** Semana con día activo destacado; resto minimizado visualmente, detalle horario debajo o lateral si ancho.

**Layout móvil:** 390: control horizontal Lun–Dom y lista Teoría/TP4 del sábado con horas reales. Selector de día en semana y agenda del día, sin pintar cuadrícula ilegible.

**Acción:** Pestañas de día son propuesta; Mes y Agenda permanecen como modos reales. **Mejora:** Prioriza tarea de hoy para usuarios de móvil sin eliminar opción Semana real.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 768x1024; one screen only, no device mockup or split before/after comparison. Screen ID S10-E, Calendario semana.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «19–25 de octubre de 2026»; «Semana»; «Lun 19»; «Mié 21»; «Sáb 24»; «Dom 25»; «TP 2 · atrasado · 18:00»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Primer parcial · 08:00».

DESKTOP 1440x900 WIREFRAME: Semana con día activo destacado; resto minimizado visualmente, detalle horario debajo o lateral si ancho.

MOBILE 390x844 WIREFRAME: 390: control horizontal Lun–Dom y lista Teoría/TP4 del sábado con horas reales.

Muestra el viewport solicitado 768x1024 con esta estructura y priorización: rango/navegación → selector modo → fila todo el día → eje horario → eventos.

ACCIÓN VISIBLE / CONTROLS: Pestañas de día son propuesta; Mes y Agenda permanecen como modos reales. Otras acciones reales relevantes: Semana anterior/siguiente; Hoy; Cambiar a Mes/Agenda; Abrir evento.

REALITY / FEASIBILITY: Hora real solo si fixture la tiene; Sin drag ni resize de evento; No duplicar Informe 28/10 fuera de semana. Sidebar real 220px desde md; lienzo restante 548px brutos; sin nav inferior. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S11 · Calendario agenda

**Código real:** `src/features/calendar/agenda-list.tsx`. **Problema UX:** Agenda debería ser opción de lectura principal en móvil manteniendo selector de vistas y eventos ordenados.

#### S11-A · Agenda contada por días

**Layout desktop:** Lista 830px con grupos Miércoles 21, Sábado 24, Domingo 25, Miércoles 28; reglas finas y cinco eventos en orden.

**Layout móvil:** 390: encabezados día completos, filas 56px, hora sobre materia si el título es largo. Grupos de día ocupan ancho disponible sin calendario miniatura.

**Acción:** Cada fila abre evento, modo Mes y Semana queda en selector superior. **Mejora:** Hace del modo Agenda una lectura adecuada al móvil sin calendario comprimido.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S11-A, Calendario agenda.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Agenda»; «Miércoles 21»; «TP 2 · atrasado · 18:00»; «Sábado 24»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Domingo 25»; «Primer parcial · 08:00»; «Miércoles 28»; «Informe de laboratorio · 20:00».

DESKTOP 1440x900 WIREFRAME: Lista 830px con grupos Miércoles 21, Sábado 24, Domingo 25, Miércoles 28; reglas finas y cinco eventos en orden.

MOBILE 390x844 WIREFRAME: 390: encabezados día completos, filas 56px, hora sobre materia si el título es largo.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: mes/controles → selector vistas → grupos por fecha → filas con hora/materia → sin fecha en pie.

ACCIÓN VISIBLE / CONTROLS: Cada fila abre evento, modo Mes y Semana queda en selector superior. Otras acciones reales relevantes: Cambiar Mes/Semana/Agenda; Abrir evento; Completar obligación desde detalle cuando aplica; Ir a hoy.

REALITY / FEASIBILITY: No confundir ausencia de eventos con ausencia de cursada; No repetir eventos de otras semanas por decoración; Sin fecha en bloque diferenciado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S11-B · Cuándo y de qué materia

**Layout desktop:** Listado 850px con columna hora 64px y materia/entrega; encabezados día compactos con subtítulos.

**Layout móvil:** 390: filas tabulares apiladas, texto «Atrasada» explícito en TP2. Grupos de día ocupan ancho disponible sin calendario miniatura.

**Acción:** Botón Hoy salta a fecha; evento mantiene enlace a detalle. **Mejora:** Se identifica más rápido el próximo parcial y las horas 09:00/18:00.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S11-B, Calendario agenda.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Agenda»; «Miércoles 21»; «TP 2 · atrasado · 18:00»; «Sábado 24»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Domingo 25»; «Primer parcial · 08:00»; «Miércoles 28»; «Informe de laboratorio · 20:00».

DESKTOP 1440x900 WIREFRAME: Listado 850px con columna hora 64px y materia/entrega; encabezados día compactos con subtítulos.

MOBILE 390x844 WIREFRAME: 390: filas tabulares apiladas, texto «Atrasada» explícito en TP2.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: mes/controles → selector vistas → grupos por fecha → filas con hora/materia → sin fecha en pie.

ACCIÓN VISIBLE / CONTROLS: Botón Hoy salta a fecha; evento mantiene enlace a detalle. Otras acciones reales relevantes: Cambiar Mes/Semana/Agenda; Abrir evento; Completar obligación desde detalle cuando aplica; Ir a hoy.

REALITY / FEASIBILITY: No confundir ausencia de eventos con ausencia de cursada; No repetir eventos de otras semanas por decoración; Sin fecha en bloque diferenciado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S11-C · Agenda con ficha de evento

**Layout desktop:** Agenda 600px y detalle 270px del evento seleccionado: título, tipo, materia y fecha del fixture.

**Layout móvil:** 390: ficha se coloca tras evento seleccionado y antes del siguiente día. Grupos de día ocupan ancho disponible sin calendario miniatura.

**Acción:** Seleccionar «Primer parcial» enseña Análisis Matemático II y acción Abrir evento. **Mejora:** Permite leer chip/evento sin depender de nombre truncado de materia.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S11-C, Calendario agenda.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Agenda»; «Miércoles 21»; «TP 2 · atrasado · 18:00»; «Sábado 24»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Domingo 25»; «Primer parcial · 08:00»; «Miércoles 28»; «Informe de laboratorio · 20:00».

DESKTOP 1440x900 WIREFRAME: Agenda 600px y detalle 270px del evento seleccionado: título, tipo, materia y fecha del fixture.

MOBILE 390x844 WIREFRAME: 390: ficha se coloca tras evento seleccionado y antes del siguiente día.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: mes/controles → selector vistas → grupos por fecha → filas con hora/materia → sin fecha en pie.

ACCIÓN VISIBLE / CONTROLS: Seleccionar «Primer parcial» enseña Análisis Matemático II y acción Abrir evento. Otras acciones reales relevantes: Cambiar Mes/Semana/Agenda; Abrir evento; Completar obligación desde detalle cuando aplica; Ir a hoy.

REALITY / FEASIBILITY: No confundir ausencia de eventos con ausencia de cursada; No repetir eventos de otras semanas por decoración; Sin fecha en bloque diferenciado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S11-D · Días conectados con materias

**Layout desktop:** Lista por fecha a izquierda y banda «Materias de estos eventos» a derecha, únicamente Arquitectura/Sistemas/Análisis del fixture.

**Layout móvil:** 390: nombre de materia como subtítulo clicable de evento; sin panel de nodos. Grupos de día ocupan ancho disponible sin calendario miniatura.

**Acción:** Enlace de materia dirige a detalle y fecha mantiene su apertura de evento. **Mejora:** Permite pasar de obligación temporal a contenido de cursada sin navegación extra ficticia.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S11-D, Calendario agenda.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Agenda»; «Miércoles 21»; «TP 2 · atrasado · 18:00»; «Sábado 24»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Domingo 25»; «Primer parcial · 08:00»; «Miércoles 28»; «Informe de laboratorio · 20:00».

DESKTOP 1440x900 WIREFRAME: Lista por fecha a izquierda y banda «Materias de estos eventos» a derecha, únicamente Arquitectura/Sistemas/Análisis del fixture.

MOBILE 390x844 WIREFRAME: 390: nombre de materia como subtítulo clicable de evento; sin panel de nodos.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: mes/controles → selector vistas → grupos por fecha → filas con hora/materia → sin fecha en pie.

ACCIÓN VISIBLE / CONTROLS: Enlace de materia dirige a detalle y fecha mantiene su apertura de evento. Otras acciones reales relevantes: Cambiar Mes/Semana/Agenda; Abrir evento; Completar obligación desde detalle cuando aplica; Ir a hoy.

REALITY / FEASIBILITY: No confundir ausencia de eventos con ausencia de cursada; No repetir eventos de otras semanas por decoración; Sin fecha en bloque diferenciado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S11-E · Un día a la vez

**Layout desktop:** Día Sábado 24 abierto con Teoría y TP4; días 21/25/28 como bloques de fecha plegables con aviso Atrasada visible.

**Layout móvil:** 390: mantener TP2 vencido visible arriba aunque sábado sea día seleccionado. Grupos de día ocupan ancho disponible sin calendario miniatura.

**Acción:** Disclosure «Ver Miércoles 28 (1)» revela informe sin ocultar navegación Mes/Semana. **Mejora:** Evita perder atrasadas al enfocar un solo día y reduce carga en agenda larga.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S11-E, Calendario agenda.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Octubre 2026»; «Agenda»; «Miércoles 21»; «TP 2 · atrasado · 18:00»; «Sábado 24»; «Teoría · 09:00»; «TP 4 · entrega · 18:00»; «Domingo 25»; «Primer parcial · 08:00»; «Miércoles 28»; «Informe de laboratorio · 20:00».

DESKTOP 1440x900 WIREFRAME: Día Sábado 24 abierto con Teoría y TP4; días 21/25/28 como bloques de fecha plegables con aviso Atrasada visible.

MOBILE 390x844 WIREFRAME: 390: mantener TP2 vencido visible arriba aunque sábado sea día seleccionado.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: mes/controles → selector vistas → grupos por fecha → filas con hora/materia → sin fecha en pie.

ACCIÓN VISIBLE / CONTROLS: Disclosure «Ver Miércoles 28 (1)» revela informe sin ocultar navegación Mes/Semana. Otras acciones reales relevantes: Cambiar Mes/Semana/Agenda; Abrir evento; Completar obligación desde detalle cuando aplica; Ir a hoy.

REALITY / FEASIBILITY: No confundir ausencia de eventos con ausencia de cursada; No repetir eventos de otras semanas por decoración; Sin fecha en bloque diferenciado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S12 · Material por materia

**Código real:** `src/routes/_app/library.tsx`. **Problema UX:** Formulario de recurso y listado por materia son dos tareas distintas en una sola página.

#### S12-A · Material ordenado por asignatura

**Layout desktop:** Columna 820px; formulario Link/Nota breve arriba con rótulos, listado por materia debajo con enlaces como referencias de lectura.

**Layout móvil:** 390: tipo, materia, título y contenido se apilan; bloque «Material de tus materias» tras Guardar. Form en una columna; eliminar acción en la propia fila.

**Acción:** Agregar link/nota y abrir/borrar recurso existente desde su fila. **Mejora:** Distingue recurso breve de la nota Markdown que solo vive en carpeta.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S12-A, Material por materia.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tu material»; «Agregar material»; «Tipo: Link o Nota breve»; «Materia: Análisis Matemático II»; «Título: Guía de ejercicios (ejemplo demo)»; «Material de tus materias».

DESKTOP 1440x900 WIREFRAME: Columna 820px; formulario Link/Nota breve arriba con rótulos, listado por materia debajo con enlaces como referencias de lectura.

MOBILE 390x844 WIREFRAME: 390: tipo, materia, título y contenido se apilan; bloque «Material de tus materias» tras Guardar.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: cabecera → agregar link/nota → agrupación materia → recursos → estado vacío/error.

ACCIÓN VISIBLE / CONTROLS: Agregar link/nota y abrir/borrar recurso existente desde su fila. Otras acciones reales relevantes: Elegir link/nota; Asociar materia; Guardar material; Abrir/borrar enlace.

REALITY / FEASIBILITY: Recurso solo enlace o nota breve; No subir PDF ni editor Markdown; El ejemplo es DEMO, no recurso real verificado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S12-B · Agregar rápido, revisar después

**Layout desktop:** Toolbar compacta de creación 840px: Tipo, Materia, Título y URL/contenido; lista densa con tipo visible.

**Layout móvil:** 390: controles apilados y CTA Guardar ancho completo; foco vuelve al Título. Form en una columna; eliminar acción en la propia fila.

**Acción:** Selector Link/Nota cambia solo el campo URL o contenido, como código. **Mejora:** Se ahorran desplazamientos al cargar varios links, manteniendo validación.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S12-B, Material por materia.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tu material»; «Agregar material»; «Tipo: Link o Nota breve»; «Materia: Análisis Matemático II»; «Título: Guía de ejercicios (ejemplo demo)»; «Material de tus materias».

DESKTOP 1440x900 WIREFRAME: Toolbar compacta de creación 840px: Tipo, Materia, Título y URL/contenido; lista densa con tipo visible.

MOBILE 390x844 WIREFRAME: 390: controles apilados y CTA Guardar ancho completo; foco vuelve al Título.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: cabecera → agregar link/nota → agrupación materia → recursos → estado vacío/error.

ACCIÓN VISIBLE / CONTROLS: Selector Link/Nota cambia solo el campo URL o contenido, como código. Otras acciones reales relevantes: Elegir link/nota; Asociar materia; Guardar material; Abrir/borrar enlace.

REALITY / FEASIBILITY: Recurso solo enlace o nota breve; No subir PDF ni editor Markdown; El ejemplo es DEMO, no recurso real verificado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S12-C · Material junto a la materia

**Layout desktop:** Formulario 530px a izquierda y vista 250px a derecha de recursos agrupados por materia seleccionada.

**Layout móvil:** 390: lista de materia seleccionada debajo del formulario, nunca panel lateral. Form en una columna; eliminar acción en la propia fila.

**Acción:** Elegir Análisis Matemático II filtra visualmente el bloque de ejemplo DEMO; guardar con backend existente. **Mejora:** Hace visible a qué curso se adscribe cada link antes de confirmar.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S12-C, Material por materia.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tu material»; «Agregar material»; «Tipo: Link o Nota breve»; «Materia: Análisis Matemático II»; «Título: Guía de ejercicios (ejemplo demo)»; «Material de tus materias».

DESKTOP 1440x900 WIREFRAME: Formulario 530px a izquierda y vista 250px a derecha de recursos agrupados por materia seleccionada.

MOBILE 390x844 WIREFRAME: 390: lista de materia seleccionada debajo del formulario, nunca panel lateral.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: cabecera → agregar link/nota → agrupación materia → recursos → estado vacío/error.

ACCIÓN VISIBLE / CONTROLS: Elegir Análisis Matemático II filtra visualmente el bloque de ejemplo DEMO; guardar con backend existente. Otras acciones reales relevantes: Elegir link/nota; Asociar materia; Guardar material; Abrir/borrar enlace.

REALITY / FEASIBILITY: Recurso solo enlace o nota breve; No subir PDF ni editor Markdown; El ejemplo es DEMO, no recurso real verificado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S12-D · De materia a recurso

**Layout desktop:** Índice por asignatura de 300px y panel 510px de recursos en texto, con «Link»/«Nota breve» claramente identificados.

**Layout móvil:** 390: secciones de materias desplegables; cada recurso lleva tipo y acción real. Form en una columna; eliminar acción en la propia fila.

**Acción:** Abrir materia de índice despliega sus recursos; no grafos de archivos. **Mejora:** Simplifica localizar un material desde la estructura académica existente.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S12-D, Material por materia.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tu material»; «Agregar material»; «Tipo: Link o Nota breve»; «Materia: Análisis Matemático II»; «Título: Guía de ejercicios (ejemplo demo)»; «Material de tus materias».

DESKTOP 1440x900 WIREFRAME: Índice por asignatura de 300px y panel 510px de recursos en texto, con «Link»/«Nota breve» claramente identificados.

MOBILE 390x844 WIREFRAME: 390: secciones de materias desplegables; cada recurso lleva tipo y acción real.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: cabecera → agregar link/nota → agrupación materia → recursos → estado vacío/error.

ACCIÓN VISIBLE / CONTROLS: Abrir materia de índice despliega sus recursos; no grafos de archivos. Otras acciones reales relevantes: Elegir link/nota; Asociar materia; Guardar material; Abrir/borrar enlace.

REALITY / FEASIBILITY: Recurso solo enlace o nota breve; No subir PDF ni editor Markdown; El ejemplo es DEMO, no recurso real verificado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S12-E · Primero encontrá, después agregá

**Layout desktop:** Lista agrupada por materia visible; franja «Agregar material» expande formulario real de 2 tipos solo cuando se requiere.

**Layout móvil:** 390: un CTA Agregar y lista primero; al activar se expande formulario con foco en Título. Form en una columna; eliminar acción en la propia fila.

**Acción:** Disclosure de formulario es FUTURO; acciones abrir/borrar siguen explícitas. **Mejora:** Evita que formulario largo empuje materiales ya guardados bajo el primer viewport.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S12-E, Material por materia.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tu material»; «Agregar material»; «Tipo: Link o Nota breve»; «Materia: Análisis Matemático II»; «Título: Guía de ejercicios (ejemplo demo)»; «Material de tus materias».

DESKTOP 1440x900 WIREFRAME: Lista agrupada por materia visible; franja «Agregar material» expande formulario real de 2 tipos solo cuando se requiere.

MOBILE 390x844 WIREFRAME: 390: un CTA Agregar y lista primero; al activar se expande formulario con foco en Título.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: cabecera → agregar link/nota → agrupación materia → recursos → estado vacío/error.

ACCIÓN VISIBLE / CONTROLS: Disclosure de formulario es FUTURO; acciones abrir/borrar siguen explícitas. Otras acciones reales relevantes: Elegir link/nota; Asociar materia; Guardar material; Abrir/borrar enlace.

REALITY / FEASIBILITY: Recurso solo enlace o nota breve; No subir PDF ni editor Markdown; El ejemplo es DEMO, no recurso real verificado. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S13 · Notas de carpeta local

**Código real:** `src/routes/_app/vault.tsx`, `src/components/workspace/workspace-shell.tsx`, `src/components/workspace/note-editor.tsx`. **Problema UX:** Explorer inicia abierto incluso en móvil (288px), puede tapar la nota; shell avanzado del documento difiere del real.

#### S13-A · Tu apunte abierto

**Layout desktop:** Nav 220px, explorer 288px, editor con nota «Clase 7 — Matrices» y lectura 740px, tabs arriba, guardado junto al título, backlinks al final.

**Layout móvil:** 390: editor primero, botón «Carpetas» abre drawer desde izquierda a pedido; solo un pane. FUTURO: explorer oculto inicial, editor dominante, botón Carpetas.

**Acción:** Ctrl+P abre nota; enlace [[Repaso parcial]] y Guardado visibles. **Mejora:** Corrige propuesta P0 de explorer inicialmente abierto cubriendo editor móvil.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S13-A, Notas de carpeta local.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Carpetas»; «Clase 7 — Matrices»; «Guardado»; «- Repasar producto de matrices»; «[[Repaso parcial]]»; «Backlinks»; «Ctrl+P abrir nota».

DESKTOP 1440x900 WIREFRAME: Nav 220px, explorer 288px, editor con nota «Clase 7 — Matrices» y lectura 740px, tabs arriba, guardado junto al título, backlinks al final.

MOBILE 390x844 WIREFRAME: 390: editor primero, botón «Carpetas» abre drawer desde izquierda a pedido; solo un pane.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: shell global → explorer condicional → tabs nota → editor markdown → estado guardado → backlinks.

ACCIÓN VISIBLE / CONTROLS: Ctrl+P abre nota; enlace [[Repaso parcial]] y Guardado visibles. Otras acciones reales relevantes: Abrir/cerrar explorer; Abrir archivo por Ctrl+P; Buscar texto Ctrl+Shift+F; Crear o abrir wikilink; Dividir panes en desktop.

REALITY / FEASIBILITY: Notas solo en carpeta local; Máximo dos panes reales; No grafo Obsidian, no drag de tabs no probado. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S13-B · Editor de trabajo preciso

**Layout desktop:** Shell full-bleed: nav 220, explorer compacto 240, tabs/herramientas y CodeMirror, ruta actual y guardado en masthead.

**Layout móvil:** 390: explorer colapsado, comando Abrir nota, título truncado con acceso al nombre completo. FUTURO: explorer oculto inicial, editor dominante, botón Carpetas.

**Acción:** Ctrl+P y Ctrl+Shift+F aparecen en toolbar; Ctrl+\ solo desktop. **Mejora:** Disminuye coste de cambiar documentos y separa buscar notas de búsqueda global.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S13-B, Notas de carpeta local.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Carpetas»; «Clase 7 — Matrices»; «Guardado»; «- Repasar producto de matrices»; «[[Repaso parcial]]»; «Backlinks»; «Ctrl+P abrir nota».

DESKTOP 1440x900 WIREFRAME: Shell full-bleed: nav 220, explorer compacto 240, tabs/herramientas y CodeMirror, ruta actual y guardado en masthead.

MOBILE 390x844 WIREFRAME: 390: explorer colapsado, comando Abrir nota, título truncado con acceso al nombre completo.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: shell global → explorer condicional → tabs nota → editor markdown → estado guardado → backlinks.

ACCIÓN VISIBLE / CONTROLS: Ctrl+P y Ctrl+Shift+F aparecen en toolbar; Ctrl+\ solo desktop. Otras acciones reales relevantes: Abrir/cerrar explorer; Abrir archivo por Ctrl+P; Buscar texto Ctrl+Shift+F; Crear o abrir wikilink; Dividir panes en desktop.

REALITY / FEASIBILITY: Notas solo en carpeta local; Máximo dos panes reales; No grafo Obsidian, no drag de tabs no probado. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S13-C · Dos apuntes en tu mesa

**Layout desktop:** Nav 220, explorer 240; pane izquierda 450 para Clase 7 — Matrices, pane derecha 450 para Repaso parcial (ambos DEMO), backlinks disponibles.

**Layout móvil:** 390: un pane, tabs permiten alternar nota; explorer cerrado por defecto. FUTURO: explorer oculto inicial, editor dominante, botón Carpetas.

**Acción:** Botón Dividir o Ctrl+\ activa segundo pane; cerrar respeta guard del editor. **Mejora:** Aprovecha el modelo real de hasta dos panes en desktop sin prometer canvas infinito.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S13-C, Notas de carpeta local.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Carpetas»; «Clase 7 — Matrices»; «Guardado»; «- Repasar producto de matrices»; «[[Repaso parcial]]»; «Backlinks»; «Ctrl+P abrir nota».

DESKTOP 1440x900 WIREFRAME: Nav 220, explorer 240; pane izquierda 450 para Clase 7 — Matrices, pane derecha 450 para Repaso parcial (ambos DEMO), backlinks disponibles.

MOBILE 390x844 WIREFRAME: 390: un pane, tabs permiten alternar nota; explorer cerrado por defecto.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: shell global → explorer condicional → tabs nota → editor markdown → estado guardado → backlinks.

ACCIÓN VISIBLE / CONTROLS: Botón Dividir o Ctrl+\ activa segundo pane; cerrar respeta guard del editor. Otras acciones reales relevantes: Abrir/cerrar explorer; Abrir archivo por Ctrl+P; Buscar texto Ctrl+Shift+F; Crear o abrir wikilink; Dividir panes en desktop.

REALITY / FEASIBILITY: Notas solo en carpeta local; Máximo dos panes reales; No grafo Obsidian, no drag de tabs no probado. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S13-D · Documentos y enlaces reales

**Layout desktop:** Editor 610px a izquierda y columna 260px de Wikilinks/Backlinks existentes como listas textuales, nunca mapa 3D.

**Layout móvil:** 390: wikilinks dentro de Markdown, backlinks tras texto al final; explorer solo vía Carpetas. FUTURO: explorer oculto inicial, editor dominante, botón Carpetas.

**Acción:** Tocar wikilink abre/crea objetivo con aviso real; Ctrl+P sigue siendo switcher. **Mejora:** Da sentido a [[Repaso parcial]] con destino legible y aviso cuando hay ambigüedad.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S13-D, Notas de carpeta local.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Carpetas»; «Clase 7 — Matrices»; «Guardado»; «- Repasar producto de matrices»; «[[Repaso parcial]]»; «Backlinks»; «Ctrl+P abrir nota».

DESKTOP 1440x900 WIREFRAME: Editor 610px a izquierda y columna 260px de Wikilinks/Backlinks existentes como listas textuales, nunca mapa 3D.

MOBILE 390x844 WIREFRAME: 390: wikilinks dentro de Markdown, backlinks tras texto al final; explorer solo vía Carpetas.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: shell global → explorer condicional → tabs nota → editor markdown → estado guardado → backlinks.

ACCIÓN VISIBLE / CONTROLS: Tocar wikilink abre/crea objetivo con aviso real; Ctrl+P sigue siendo switcher. Otras acciones reales relevantes: Abrir/cerrar explorer; Abrir archivo por Ctrl+P; Buscar texto Ctrl+Shift+F; Crear o abrir wikilink; Dividir panes en desktop.

REALITY / FEASIBILITY: Notas solo en carpeta local; Máximo dos panes reales; No grafo Obsidian, no drag de tabs no probado. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S13-E · Escribí sin paneles encima

**Layout desktop:** Editor único 730px centrado; cabezal título y «Guardado»; explorer, backlinks y búsqueda se abren con controles discretos.

**Layout móvil:** 390: nota ocupa ancho 100%; carpetas panel temporal, guardado visible junto al encabezado. FUTURO: explorer oculto inicial, editor dominante, botón Carpetas.

**Acción:** «Carpetas» abre drawer, «Vínculos entrantes» despliega backlinks, Ctrl+Shift+F busca notas. **Mejora:** Concentra escritura y reduce carga de tres capas de navegación sin perder acceso.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S13-E, Notas de carpeta local.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Carpetas»; «Clase 7 — Matrices»; «Guardado»; «- Repasar producto de matrices»; «[[Repaso parcial]]»; «Backlinks»; «Ctrl+P abrir nota».

DESKTOP 1440x900 WIREFRAME: Editor único 730px centrado; cabezal título y «Guardado»; explorer, backlinks y búsqueda se abren con controles discretos.

MOBILE 390x844 WIREFRAME: 390: nota ocupa ancho 100%; carpetas panel temporal, guardado visible junto al encabezado.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: shell global → explorer condicional → tabs nota → editor markdown → estado guardado → backlinks.

ACCIÓN VISIBLE / CONTROLS: «Carpetas» abre drawer, «Vínculos entrantes» despliega backlinks, Ctrl+Shift+F busca notas. Otras acciones reales relevantes: Abrir/cerrar explorer; Abrir archivo por Ctrl+P; Buscar texto Ctrl+Shift+F; Crear o abrir wikilink; Dividir panes en desktop.

REALITY / FEASIBILITY: Notas solo en carpeta local; Máximo dos panes reales; No grafo Obsidian, no drag de tabs no probado. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S14 · Notas no disponibles en Cloud

**Código real:** `src/routes/_app/vault.tsx`. **Problema UX:** El estado informativo debe explicar por qué no se muestra editor si solo se usa Cloud.

#### S14-A · Dónde están tus notas

**Layout desktop:** Columna 520px, ícono carpeta lineal 48px, título «Tus notas viven en tu computadora» y explicación sin editor.

**Layout móvil:** 390: mensaje alineado en lectura con mucho espacio para barra inferior, sin placeholder de nota. Vacío accesible sobre barra inferior sin botón de editor.

**Acción:** Solo mostrar «Cambiar espacio» si workspace.change admite abrir carpeta. **Mejora:** Evita que un espacio vacío parezca falla de carga del Cloud.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S14-A, Notas no disponibles en Cloud.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus notas viven en tu computadora»; «Abrí Campus desde una carpeta local para editarlas.»; «Cloud guarda la cursada de tu cuenta.».

DESKTOP 1440x900 WIREFRAME: Columna 520px, ícono carpeta lineal 48px, título «Tus notas viven en tu computadora» y explicación sin editor.

MOBILE 390x844 WIREFRAME: 390: mensaje alineado en lectura con mucho espacio para barra inferior, sin placeholder de nota.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: ícono carpeta lineal → mensaje → explicación → destino disponible.

ACCIÓN VISIBLE / CONTROLS: Solo mostrar «Cambiar espacio» si workspace.change admite abrir carpeta. Otras acciones reales relevantes: Leer explicación; Ir a cambiar espacio solo si runtime ofrece acción; Volver a otra sección mediante navegación.

REALITY / FEASIBILITY: No renderizar editor Cloud; No CTA ficticia de sincronización; Mensaje centrado con una sola acción cuando exista. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S14-B · Disponibilidad de notas explícita

**Layout desktop:** Estado vacío 560px: etiqueta Cloud, título, explicación técnica breve y acción condicional, delimitado por una regla.

**Layout móvil:** 390: etiqueta «Cloud» y causa antes del CTA condicional. Vacío accesible sobre barra inferior sin botón de editor.

**Acción:** Link a selector si disponible; sin botón de sincronizar. **Mejora:** Hace visible que buscar una nota de carpeta no es una operación de Cloud.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S14-B, Notas no disponibles en Cloud.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus notas viven en tu computadora»; «Abrí Campus desde una carpeta local para editarlas.»; «Cloud guarda la cursada de tu cuenta.».

DESKTOP 1440x900 WIREFRAME: Estado vacío 560px: etiqueta Cloud, título, explicación técnica breve y acción condicional, delimitado por una regla.

MOBILE 390x844 WIREFRAME: 390: etiqueta «Cloud» y causa antes del CTA condicional.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: ícono carpeta lineal → mensaje → explicación → destino disponible.

ACCIÓN VISIBLE / CONTROLS: Link a selector si disponible; sin botón de sincronizar. Otras acciones reales relevantes: Leer explicación; Ir a cambiar espacio solo si runtime ofrece acción; Volver a otra sección mediante navegación.

REALITY / FEASIBILITY: No renderizar editor Cloud; No CTA ficticia de sincronización; Mensaje centrado con una sola acción cuando exista. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S14-C · Información de espacio en contexto

**Layout desktop:** Nota principal 430px y columna 250px con explicación «Datos de cursada en Cloud / notas en carpeta local», texto sin control.

**Layout móvil:** 390: comparación de procedencia debajo del título en dos filas. Vacío accesible sobre barra inferior sin botón de editor.

**Acción:** Cambiar espacio se presenta solo en runtime capaz de hacerlo. **Mejora:** Explica procedencia distinta de los datos para evitar falsas expectativas de sincronía.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S14-C, Notas no disponibles en Cloud.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus notas viven en tu computadora»; «Abrí Campus desde una carpeta local para editarlas.»; «Cloud guarda la cursada de tu cuenta.».

DESKTOP 1440x900 WIREFRAME: Nota principal 430px y columna 250px con explicación «Datos de cursada en Cloud / notas en carpeta local», texto sin control.

MOBILE 390x844 WIREFRAME: 390: comparación de procedencia debajo del título en dos filas.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: ícono carpeta lineal → mensaje → explicación → destino disponible.

ACCIÓN VISIBLE / CONTROLS: Cambiar espacio se presenta solo en runtime capaz de hacerlo. Otras acciones reales relevantes: Leer explicación; Ir a cambiar espacio solo si runtime ofrece acción; Volver a otra sección mediante navegación.

REALITY / FEASIBILITY: No renderizar editor Cloud; No CTA ficticia de sincronización; Mensaje centrado con una sola acción cuando exista. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S14-D · Rutas para llegar a notas

**Layout desktop:** Secuencia lineal «Elegir carpeta → Abrir notas locales» en bloque 600px y aviso Cloud actual.

**Layout móvil:** 390: paso a paso vertical, sin imagen de archivo remoto. Vacío accesible sobre barra inferior sin botón de editor.

**Acción:** Un solo enlace real al selector cuando el entorno local permite carpetas. **Mejora:** Orienta desde cuenta Cloud hacia una carpeta válida sin simular transferencia de datos.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S14-D, Notas no disponibles en Cloud.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus notas viven en tu computadora»; «Abrí Campus desde una carpeta local para editarlas.»; «Cloud guarda la cursada de tu cuenta.».

DESKTOP 1440x900 WIREFRAME: Secuencia lineal «Elegir carpeta → Abrir notas locales» en bloque 600px y aviso Cloud actual.

MOBILE 390x844 WIREFRAME: 390: paso a paso vertical, sin imagen de archivo remoto.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: ícono carpeta lineal → mensaje → explicación → destino disponible.

ACCIÓN VISIBLE / CONTROLS: Un solo enlace real al selector cuando el entorno local permite carpetas. Otras acciones reales relevantes: Leer explicación; Ir a cambiar espacio solo si runtime ofrece acción; Volver a otra sección mediante navegación.

REALITY / FEASIBILITY: No renderizar editor Cloud; No CTA ficticia de sincronización; Mensaje centrado con una sola acción cuando exista. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S14-E · No hay editor aquí

**Layout desktop:** Título claro y una frase única al centro de 520px; explicación adicional tras «¿Por qué?» sin pseudo-funciones.

**Layout móvil:** 390: ninguna ilustración ocupa más de 64px; CTA única si existe. Vacío accesible sobre barra inferior sin botón de editor.

**Acción:** Desplegar ayuda opcional; ir a Hoy desde bottom tabs sigue disponible. **Mejora:** Reduce el desconcierto sin prometer solución automática al no-vault.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S14-E, Notas no disponibles en Cloud.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Tus notas viven en tu computadora»; «Abrí Campus desde una carpeta local para editarlas.»; «Cloud guarda la cursada de tu cuenta.».

DESKTOP 1440x900 WIREFRAME: Título claro y una frase única al centro de 520px; explicación adicional tras «¿Por qué?» sin pseudo-funciones.

MOBILE 390x844 WIREFRAME: 390: ninguna ilustración ocupa más de 64px; CTA única si existe.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: ícono carpeta lineal → mensaje → explicación → destino disponible.

ACCIÓN VISIBLE / CONTROLS: Desplegar ayuda opcional; ir a Hoy desde bottom tabs sigue disponible. Otras acciones reales relevantes: Leer explicación; Ir a cambiar espacio solo si runtime ofrece acción; Volver a otra sección mediante navegación.

REALITY / FEASIBILITY: No renderizar editor Cloud; No CTA ficticia de sincronización; Mensaje centrado con una sola acción cuando exista. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S15 · Ajustes

**Código real:** `src/routes/_app/settings.tsx`. **Problema UX:** Opciones tema/acento, ubicación, cuenta, carrera y privacidad requieren agrupaciones reconocibles.

#### S15-A · Ajustes como secciones de cuaderno

**Layout desktop:** Columna 820px: Apariencia; tema en selector Claro/Oscuro/Sistema, colores con nombres; Tu carpeta/Cuenta/Carrera separados por reglas.

**Layout móvil:** 390: presets de color en 2 filas, ubicación con wrap, CTA Cambiar espacio. Segmented tema ajustado a ancho, presets envuelven con nombre accesible.

**Acción:** aria-pressed en swatches, cambio de tema inmediato y visible. **Mejora:** Hace escaneables preferencias reales sin paneles de administración falsos.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S15-A, Ajustes.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ajustes»; «Apariencia»; «Claro»; «Oscuro»; «Como el sistema»; «Color de acento: Turquesa»; «Dónde trabajás»; «Tu carrera»; «Cambiar de espacio de trabajo».

DESKTOP 1440x900 WIREFRAME: Columna 820px: Apariencia; tema en selector Claro/Oscuro/Sistema, colores con nombres; Tu carpeta/Cuenta/Carrera separados por reglas.

MOBILE 390x844 WIREFRAME: 390: presets de color en 2 filas, ubicación con wrap, CTA Cambiar espacio.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: apariencia tema → acentos → workspace/carpeta → cuenta condicional → carrera → privacidad.

ACCIÓN VISIBLE / CONTROLS: aria-pressed en swatches, cambio de tema inmediato y visible. Otras acciones reales relevantes: Cambiar tema; Elegir preset de acento; Cambiar espacio; Cerrar sesión si Cloud; Cambiar carrera.

REALITY / FEASIBILITY: Acentos son presets limitados, no selector arbitrario; Cuenta solo si requiere sesión; Dirección carpeta solo si carpeta local. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S15-B · Preferencias de una mirada

**Layout desktop:** Lista densa en filas Nombre/Valor para tema, acento y workspace; selector tema claramente agrupado y swatches etiquetados.

**Layout móvil:** 390: nombre de ajuste arriba, control debajo; prescindir de tabla horizontal. Segmented tema ajustado a ancho, presets envuelven con nombre accesible.

**Acción:** Tema cambia al tocar, preset también, cuenta solo si Cloud. **Mejora:** Permite revisar configuración actual más rápido, incluido Turquesa predeterminado.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S15-B, Ajustes.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ajustes»; «Apariencia»; «Claro»; «Oscuro»; «Como el sistema»; «Color de acento: Turquesa»; «Dónde trabajás»; «Tu carrera»; «Cambiar de espacio de trabajo».

DESKTOP 1440x900 WIREFRAME: Lista densa en filas Nombre/Valor para tema, acento y workspace; selector tema claramente agrupado y swatches etiquetados.

MOBILE 390x844 WIREFRAME: 390: nombre de ajuste arriba, control debajo; prescindir de tabla horizontal.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: apariencia tema → acentos → workspace/carpeta → cuenta condicional → carrera → privacidad.

ACCIÓN VISIBLE / CONTROLS: Tema cambia al tocar, preset también, cuenta solo si Cloud. Otras acciones reales relevantes: Cambiar tema; Elegir preset de acento; Cambiar espacio; Cerrar sesión si Cloud; Cambiar carrera.

REALITY / FEASIBILITY: Acentos son presets limitados, no selector arbitrario; Cuenta solo si requiere sesión; Dirección carpeta solo si carpeta local. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S15-C · Apariencia con contexto

**Layout desktop:** Columna 560px con controles y panel 240px que muestra ejemplo de texto/botón en paleta elegida sin guardar ajustes extra.

**Layout móvil:** 390: mini-preview bajo acento, antes de espacio/carrera. Segmented tema ajustado a ancho, presets envuelven con nombre accesible.

**Acción:** Preset actualiza vista previa propuesta; save global no existe. **Mejora:** Ayuda a elegir acento con contraste en contexto, inspirado en método de Realtime Colors sin copiar UI.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S15-C, Ajustes.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ajustes»; «Apariencia»; «Claro»; «Oscuro»; «Como el sistema»; «Color de acento: Turquesa»; «Dónde trabajás»; «Tu carrera»; «Cambiar de espacio de trabajo».

DESKTOP 1440x900 WIREFRAME: Columna 560px con controles y panel 240px que muestra ejemplo de texto/botón en paleta elegida sin guardar ajustes extra.

MOBILE 390x844 WIREFRAME: 390: mini-preview bajo acento, antes de espacio/carrera.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: apariencia tema → acentos → workspace/carpeta → cuenta condicional → carrera → privacidad.

ACCIÓN VISIBLE / CONTROLS: Preset actualiza vista previa propuesta; save global no existe. Otras acciones reales relevantes: Cambiar tema; Elegir preset de acento; Cambiar espacio; Cerrar sesión si Cloud; Cambiar carrera.

REALITY / FEASIBILITY: Acentos son presets limitados, no selector arbitrario; Cuenta solo si requiere sesión; Dirección carpeta solo si carpeta local. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S15-D · De cuenta a carrera

**Layout desktop:** Secciones lineales de procedencia Espacio → Cuenta (si Cloud) → Carrera y Apariencia separada al inicio.

**Layout móvil:** 390: títulos y valores clave como renglones, cambio de espacio/carrera en cada sección. Segmented tema ajustado a ancho, presets envuelven con nombre accesible.

**Acción:** Cada acción usa workspace.change / cambio carrera ya existentes. **Mejora:** Aclara dependencia real entre espacio, identidad y plan académico.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S15-D, Ajustes.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ajustes»; «Apariencia»; «Claro»; «Oscuro»; «Como el sistema»; «Color de acento: Turquesa»; «Dónde trabajás»; «Tu carrera»; «Cambiar de espacio de trabajo».

DESKTOP 1440x900 WIREFRAME: Secciones lineales de procedencia Espacio → Cuenta (si Cloud) → Carrera y Apariencia separada al inicio.

MOBILE 390x844 WIREFRAME: 390: títulos y valores clave como renglones, cambio de espacio/carrera en cada sección.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: apariencia tema → acentos → workspace/carpeta → cuenta condicional → carrera → privacidad.

ACCIÓN VISIBLE / CONTROLS: Cada acción usa workspace.change / cambio carrera ya existentes. Otras acciones reales relevantes: Cambiar tema; Elegir preset de acento; Cambiar espacio; Cerrar sesión si Cloud; Cambiar carrera.

REALITY / FEASIBILITY: Acentos son presets limitados, no selector arbitrario; Cuenta solo si requiere sesión; Dirección carpeta solo si carpeta local. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S15-E · Cambiá una preferencia por vez

**Layout desktop:** Apariencia abierta, demás secciones Tu espacio/Tu cuenta/Tu carrera en disclosures accesibles; tema siempre visible.

**Layout móvil:** 390: selector tema ocupa ancho y acentos se envuelven; disclosures sin ocultar opción Cerrar sesión al abrir Cuenta. Segmented tema ajustado a ancho, presets envuelven con nombre accesible.

**Acción:** Cambiar tema sin botón Guardar; abrir Carrera para ver/sustituir plan. **Mejora:** Reduce scroll de ajustes sin eliminar controles condicionales existentes.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S15-E, Ajustes.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Ajustes»; «Apariencia»; «Claro»; «Oscuro»; «Como el sistema»; «Color de acento: Turquesa»; «Dónde trabajás»; «Tu carrera»; «Cambiar de espacio de trabajo».

DESKTOP 1440x900 WIREFRAME: Apariencia abierta, demás secciones Tu espacio/Tu cuenta/Tu carrera en disclosures accesibles; tema siempre visible.

MOBILE 390x844 WIREFRAME: 390: selector tema ocupa ancho y acentos se envuelven; disclosures sin ocultar opción Cerrar sesión al abrir Cuenta.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: apariencia tema → acentos → workspace/carpeta → cuenta condicional → carrera → privacidad.

ACCIÓN VISIBLE / CONTROLS: Cambiar tema sin botón Guardar; abrir Carrera para ver/sustituir plan. Otras acciones reales relevantes: Cambiar tema; Elegir preset de acento; Cambiar espacio; Cerrar sesión si Cloud; Cambiar carrera.

REALITY / FEASIBILITY: Acentos son presets limitados, no selector arbitrario; Cuenta solo si requiere sesión; Dirección carpeta solo si carpeta local. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S16 · Captura rápida

**Código real:** `src/components/quick-capture.tsx`, `src/components/ui/modal.tsx`. **Problema UX:** Botón móvil dice Agregar entrega aunque tipos incluyen fecha, tarea, clase, parcial y final.

#### S16-A · Una fecha bien cargada

**Layout desktop:** Overlay en Hoy atenuado con modal 520px; nombre arriba, Tipo/Materia, Fecha/Hora, regla, Cancelar/Guardar.

**Layout móvil:** 390: sheet desde abajo con input título primero y acciones pegadas al panel, teclado sin tapar fecha. Bottom sheet de alto adaptable al teclado; 1 columna.

**Acción:** Ctrl/Cmd+K abre; error junto a fecha y conserva datos al fallar. **Mejora:** Mejora etiqueta genérica del FAB y explica diferencia hora opcional/todo el día.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S16-A, Captura rápida.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Agregar fecha o tarea»; «¿Qué es?»; «TP 4 · entrega (borrador demo)»; «Entrega»; «Sistemas y Procesos de Negocio»; «24/10/2026»; «18:00»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Overlay en Hoy atenuado con modal 520px; nombre arriba, Tipo/Materia, Fecha/Hora, regla, Cancelar/Guardar.

MOBILE 390x844 WIREFRAME: 390: sheet desde abajo con input título primero y acciones pegadas al panel, teclado sin tapar fecha.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → campo nombre → tipo/materia → fecha/hora → validación → acciones.

ACCIÓN VISIBLE / CONTROLS: Ctrl/Cmd+K abre; error junto a fecha y conserva datos al fallar. Otras acciones reales relevantes: Abrir Ctrl/Cmd+K o +; Elegir tipo y materia; Ingresar fecha/hora opcional; Guardar o cancelar.

REALITY / FEASIBILITY: Es borrador para mockup, no segundo item guardado; Modal retiene foco y muestra error; Hora opcional, sin NLP ni recurrente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S16-B · Captura de cuatro datos

**Layout desktop:** Dialog 520px, secuencia tabular Nombre/Tipo+Materia/Fecha+Hora; labels 13px, campos de altura 44px.

**Layout móvil:** 390: apilar pares y mantener botón Guardar accesible; metadata del tipo visible. Bottom sheet de alto adaptable al teclado; 1 columna.

**Acción:** Enter envía después validación, Escape cancela y devuelve foco. **Mejora:** Acelera cargar TP4 de prueba sin confundir tipo parcial/clase/tarea.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S16-B, Captura rápida.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Agregar fecha o tarea»; «¿Qué es?»; «TP 4 · entrega (borrador demo)»; «Entrega»; «Sistemas y Procesos de Negocio»; «24/10/2026»; «18:00»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Dialog 520px, secuencia tabular Nombre/Tipo+Materia/Fecha+Hora; labels 13px, campos de altura 44px.

MOBILE 390x844 WIREFRAME: 390: apilar pares y mantener botón Guardar accesible; metadata del tipo visible.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → campo nombre → tipo/materia → fecha/hora → validación → acciones.

ACCIÓN VISIBLE / CONTROLS: Enter envía después validación, Escape cancela y devuelve foco. Otras acciones reales relevantes: Abrir Ctrl/Cmd+K o +; Elegir tipo y materia; Ingresar fecha/hora opcional; Guardar o cancelar.

REALITY / FEASIBILITY: Es borrador para mockup, no segundo item guardado; Modal retiene foco y muestra error; Hora opcional, sin NLP ni recurrente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S16-C · Captura con materia presente

**Layout desktop:** Dialog principal 500px y tira lateral 210px con materia preseleccionada desde detalle (solo si origen real la aporta).

**Layout móvil:** 390: resumen «Sistemas y Procesos de Negocio» debajo del selector, sin segunda columna. Bottom sheet de alto adaptable al teclado; 1 columna.

**Acción:** Selector Materia cambia resumen contextual; ningún autocompletado de lenguaje natural. **Mejora:** Confirma a qué materia irá la entrega antes de guardar.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S16-C, Captura rápida.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Agregar fecha o tarea»; «¿Qué es?»; «TP 4 · entrega (borrador demo)»; «Entrega»; «Sistemas y Procesos de Negocio»; «24/10/2026»; «18:00»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Dialog principal 500px y tira lateral 210px con materia preseleccionada desde detalle (solo si origen real la aporta).

MOBILE 390x844 WIREFRAME: 390: resumen «Sistemas y Procesos de Negocio» debajo del selector, sin segunda columna.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → campo nombre → tipo/materia → fecha/hora → validación → acciones.

ACCIÓN VISIBLE / CONTROLS: Selector Materia cambia resumen contextual; ningún autocompletado de lenguaje natural. Otras acciones reales relevantes: Abrir Ctrl/Cmd+K o +; Elegir tipo y materia; Ingresar fecha/hora opcional; Guardar o cancelar.

REALITY / FEASIBILITY: Es borrador para mockup, no segundo item guardado; Modal retiene foco y muestra error; Hora opcional, sin NLP ni recurrente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S16-D · Fecha vinculada a cursada

**Layout desktop:** Modal de 530px ordenado por Nombre → Tipo → Materia → Fecha/Hora con conectores textuales de asociación.

**Layout móvil:** 390: etiquetas paso a paso sin stepper adicional ni wizard ficticio. Bottom sheet de alto adaptable al teclado; 1 columna.

**Acción:** Elegir tipo «Final» muestra aviso real y materia sigue seleccionable. **Mejora:** Aclara vínculo item-materia necesario para verlo en Hoy/Calendario.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S16-D, Captura rápida.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Agregar fecha o tarea»; «¿Qué es?»; «TP 4 · entrega (borrador demo)»; «Entrega»; «Sistemas y Procesos de Negocio»; «24/10/2026»; «18:00»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Modal de 530px ordenado por Nombre → Tipo → Materia → Fecha/Hora con conectores textuales de asociación.

MOBILE 390x844 WIREFRAME: 390: etiquetas paso a paso sin stepper adicional ni wizard ficticio.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → campo nombre → tipo/materia → fecha/hora → validación → acciones.

ACCIÓN VISIBLE / CONTROLS: Elegir tipo «Final» muestra aviso real y materia sigue seleccionable. Otras acciones reales relevantes: Abrir Ctrl/Cmd+K o +; Elegir tipo y materia; Ingresar fecha/hora opcional; Guardar o cancelar.

REALITY / FEASIBILITY: Es borrador para mockup, no segundo item guardado; Modal retiene foco y muestra error; Hora opcional, sin NLP ni recurrente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S16-E · Escribí primero qué tenés

**Layout desktop:** Campo ¿Qué es? amplio y fecha destacada; Tipo y Materia visibles como sección «Detalles» desplegable solo si defaults válidos.

**Layout móvil:** 390: título+fecha al frente, botón «Detalles: Entrega · Sistemas…» siempre comprensible. Bottom sheet de alto adaptable al teclado; 1 columna.

**Acción:** Revisar detalles antes de Guardar; el error abre y enfoca sección automáticamente. **Mejora:** Prueba captura más veloz sin eliminar selección requerida ni validación.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S16-E, Captura rápida.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Agregar fecha o tarea»; «¿Qué es?»; «TP 4 · entrega (borrador demo)»; «Entrega»; «Sistemas y Procesos de Negocio»; «24/10/2026»; «18:00»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Campo ¿Qué es? amplio y fecha destacada; Tipo y Materia visibles como sección «Detalles» desplegable solo si defaults válidos.

MOBILE 390x844 WIREFRAME: 390: título+fecha al frente, botón «Detalles: Entrega · Sistemas…» siempre comprensible.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: título → campo nombre → tipo/materia → fecha/hora → validación → acciones.

ACCIÓN VISIBLE / CONTROLS: Revisar detalles antes de Guardar; el error abre y enfoca sección automáticamente. Otras acciones reales relevantes: Abrir Ctrl/Cmd+K o +; Elegir tipo y materia; Ingresar fecha/hora opcional; Guardar o cancelar.

REALITY / FEASIBILITY: Es borrador para mockup, no segundo item guardado; Modal retiene foco y muestra error; Hora opcional, sin NLP ni recurrente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S17 · Búsqueda global

**Código real:** `src/features/search/search-palette.tsx`. **Problema UX:** Búsqueda de materias/tareas/recursos podría confundirse con búsqueda de contenido Markdown del Vault.

#### S17-A · Buscar Campus, no tus archivos

**Layout desktop:** Diálogo 620px sobre app, input y grupos Materias/Fechas/Material con resultados en líneas de papel.

**Layout móvil:** 390: modal ancho total menos 16px, resultados scrollables sobre teclado. Dialog sin quedar bajo teclado virtual, lista de resultado accesible.

**Acción:** / abre, Esc cierra, Enter navega a resultado seleccionado. **Mejora:** Desambigua el índice académico del buscador local de notas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S17-A, Búsqueda global.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Buscar en Campus»; «Análisis Matemático II · Materia»; «Primer parcial · Tarea/fecha»; «Sistemas y Procesos de Negocio · Materia»; «/ Buscar».

DESKTOP 1440x900 WIREFRAME: Diálogo 620px sobre app, input y grupos Materias/Fechas/Material con resultados en líneas de papel.

MOBILE 390x844 WIREFRAME: 390: modal ancho total menos 16px, resultados scrollables sobre teclado.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: overlay → input → categorías → resultados → vacío sin coincidencias.

ACCIÓN VISIBLE / CONTROLS: / abre, Esc cierra, Enter navega a resultado seleccionado. Otras acciones reales relevantes: Abrir con /; Escribir consulta; Elegir resultado categorizado; Cerrar Escape.

REALITY / FEASIBILITY: No mezclar índice de archivos de notas; Resultados reales solo si se hallan; Sin autocompletar semántico de IA. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S17-B · Resultados listos para elegir

**Layout desktop:** Diálogo 620px con input 48px, categorías y filas compactas con tipo + nombre; atajo / mostrado en el header.

**Layout móvil:** 390: cada fila 52px y materia debajo de evento para no truncar. Dialog sin quedar bajo teclado virtual, lista de resultado accesible.

**Acción:** Flechas desplazan foco entre resultados reales; tecla Enter abre. **Mejora:** Reduce errores de seleccionar «Primer parcial» creyendo abrir nota homónima.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S17-B, Búsqueda global.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Buscar en Campus»; «Análisis Matemático II · Materia»; «Primer parcial · Tarea/fecha»; «Sistemas y Procesos de Negocio · Materia»; «/ Buscar».

DESKTOP 1440x900 WIREFRAME: Diálogo 620px con input 48px, categorías y filas compactas con tipo + nombre; atajo / mostrado en el header.

MOBILE 390x844 WIREFRAME: 390: cada fila 52px y materia debajo de evento para no truncar.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: overlay → input → categorías → resultados → vacío sin coincidencias.

ACCIÓN VISIBLE / CONTROLS: Flechas desplazan foco entre resultados reales; tecla Enter abre. Otras acciones reales relevantes: Abrir con /; Escribir consulta; Elegir resultado categorizado; Cerrar Escape.

REALITY / FEASIBILITY: No mezclar índice de archivos de notas; Resultados reales solo si se hallan; Sin autocompletar semántico de IA. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S17-C · Búsqueda y contexto semántico

**Layout desktop:** Diálogo 600px con lista a izquierda y descripción tipo/materia del resultado activo 220px a derecha.

**Layout móvil:** 390: descripción bajo resultado seleccionado; sin preview de contenidos no indexados. Dialog sin quedar bajo teclado virtual, lista de resultado accesible.

**Acción:** Selección activa previsualiza categoría y al Enter navega. **Mejora:** Muestra procedencia de un parcial frente a una materia sin prometer búsqueda full-text.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S17-C, Búsqueda global.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Buscar en Campus»; «Análisis Matemático II · Materia»; «Primer parcial · Tarea/fecha»; «Sistemas y Procesos de Negocio · Materia»; «/ Buscar».

DESKTOP 1440x900 WIREFRAME: Diálogo 600px con lista a izquierda y descripción tipo/materia del resultado activo 220px a derecha.

MOBILE 390x844 WIREFRAME: 390: descripción bajo resultado seleccionado; sin preview de contenidos no indexados.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: overlay → input → categorías → resultados → vacío sin coincidencias.

ACCIÓN VISIBLE / CONTROLS: Selección activa previsualiza categoría y al Enter navega. Otras acciones reales relevantes: Abrir con /; Escribir consulta; Elegir resultado categorizado; Cerrar Escape.

REALITY / FEASIBILITY: No mezclar índice de archivos de notas; Resultados reales solo si se hallan; Sin autocompletar semántico de IA. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S17-D · Entradas ordenadas por entidad

**Layout desktop:** Árbol textual Materias → Ítems de materia y Material dentro de resultados reales, sin nuevos endpoints.

**Layout móvil:** 390: grupos planos con nombre de categoría, profundidad máxima dos niveles. Dialog sin quedar bajo teclado virtual, lista de resultado accesible.

**Acción:** Entradas agrupadas mantienen navegación real a entidad, no árbol editable. **Mejora:** Da una ruta de búsqueda reconocible desde concepto académico en vez de lista heterogénea.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S17-D, Búsqueda global.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Buscar en Campus»; «Análisis Matemático II · Materia»; «Primer parcial · Tarea/fecha»; «Sistemas y Procesos de Negocio · Materia»; «/ Buscar».

DESKTOP 1440x900 WIREFRAME: Árbol textual Materias → Ítems de materia y Material dentro de resultados reales, sin nuevos endpoints.

MOBILE 390x844 WIREFRAME: 390: grupos planos con nombre de categoría, profundidad máxima dos niveles.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: overlay → input → categorías → resultados → vacío sin coincidencias.

ACCIÓN VISIBLE / CONTROLS: Entradas agrupadas mantienen navegación real a entidad, no árbol editable. Otras acciones reales relevantes: Abrir con /; Escribir consulta; Elegir resultado categorizado; Cerrar Escape.

REALITY / FEASIBILITY: No mezclar índice de archivos de notas; Resultados reales solo si se hallan; Sin autocompletar semántico de IA. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S17-E · Una consulta, primeros resultados

**Layout desktop:** Input grande y lista con categoría del match principal; demás categorías en grupos accesibles con conteos solo si calculados.

**Layout móvil:** 390: búsqueda ocupa parte alta, máximo tres resultados prioritarios visibles y acción «Ver todos» si existen. Dialog sin quedar bajo teclado virtual, lista de resultado accesible.

**Acción:** «Ver todos» expande mismo conjunto filtrado, no genera recomendaciones IA. **Mejora:** Disminuye carga en primeras teclas mientras preserva todo resultado encontrable.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S17-E, Búsqueda global.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Buscar en Campus»; «Análisis Matemático II · Materia»; «Primer parcial · Tarea/fecha»; «Sistemas y Procesos de Negocio · Materia»; «/ Buscar».

DESKTOP 1440x900 WIREFRAME: Input grande y lista con categoría del match principal; demás categorías en grupos accesibles con conteos solo si calculados.

MOBILE 390x844 WIREFRAME: 390: búsqueda ocupa parte alta, máximo tres resultados prioritarios visibles y acción «Ver todos» si existen.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: overlay → input → categorías → resultados → vacío sin coincidencias.

ACCIÓN VISIBLE / CONTROLS: «Ver todos» expande mismo conjunto filtrado, no genera recomendaciones IA. Otras acciones reales relevantes: Abrir con /; Escribir consulta; Elegir resultado categorizado; Cerrar Escape.

REALITY / FEASIBILITY: No mezclar índice de archivos de notas; Resultados reales solo si se hallan; Sin autocompletar semántico de IA. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S18 · Abrir/buscar notas

**Código real:** `src/components/workspace/quick-switcher.tsx`, `src/components/workspace/search-dialog.tsx`. **Problema UX:** Ctrl+P abre archivo y Ctrl+Shift+F busca contenido; deben tener etiquetas inequívocas distintas de búsqueda global.

#### S18-A · Abrir una nota del equipo

**Layout desktop:** Diálogo 560px sobre CodeMirror y explorador, título «Abrir nota · Ctrl+P», lista de archivos locales, ayuda Buscar en notas en pie.

**Layout móvil:** 390: overlay único sobre editor con teclado y nombres de archivo completos en dos líneas. Overlay con campo visible sobre teclado y scroll propio.

**Acción:** Ctrl+P abre archivos; enlace Ctrl+Shift+F cambia diálogo de búsqueda. **Mejora:** Diferencia switcher de archivos de búsqueda por contenido y de búsqueda global.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S18-A, Abrir/buscar notas.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Abrir nota · Ctrl+P»; «Clase 7 — Matrices.md»; «Repaso parcial.md (demo)»; «Buscar en notas · Ctrl+Shift+F»; «Sin resultados».

DESKTOP 1440x900 WIREFRAME: Diálogo 560px sobre CodeMirror y explorador, título «Abrir nota · Ctrl+P», lista de archivos locales, ayuda Buscar en notas en pie.

MOBILE 390x844 WIREFRAME: 390: overlay único sobre editor con teclado y nombres de archivo completos en dos líneas.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: editor de fondo → diálogo de notas → búsqueda → lista de archivos o matches → ayuda de atajos.

ACCIÓN VISIBLE / CONTROLS: Ctrl+P abre archivos; enlace Ctrl+Shift+F cambia diálogo de búsqueda. Otras acciones reales relevantes: Ctrl+P elegir archivo; Ctrl+Shift+F buscar contenido; Abrir resultado y enfocar editor; Cerrar Esc.

REALITY / FEASIBILITY: Sólo carpeta local; Nombres de notas son DEMO; No buscar notas en Cloud ni mezclar con búsqueda global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S18-B · Switcher compacto de archivos

**Layout desktop:** Popover 560px con input y filas de nombre + ruta; shortcut keycaps pequeños y foco de la fila actual.

**Layout móvil:** 390: lista de archivos ocupa viewport restante, ruta secundaria bajo nombre. Overlay con campo visible sobre teclado y scroll propio.

**Acción:** Ctrl+P, escribir fragmento, Enter abre la nota elegida. **Mejora:** Reduce el recorrido para cambiar Clase 7 y Repaso parcial sin tocar explorer.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S18-B, Abrir/buscar notas.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Abrir nota · Ctrl+P»; «Clase 7 — Matrices.md»; «Repaso parcial.md (demo)»; «Buscar en notas · Ctrl+Shift+F»; «Sin resultados».

DESKTOP 1440x900 WIREFRAME: Popover 560px con input y filas de nombre + ruta; shortcut keycaps pequeños y foco de la fila actual.

MOBILE 390x844 WIREFRAME: 390: lista de archivos ocupa viewport restante, ruta secundaria bajo nombre.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: editor de fondo → diálogo de notas → búsqueda → lista de archivos o matches → ayuda de atajos.

ACCIÓN VISIBLE / CONTROLS: Ctrl+P, escribir fragmento, Enter abre la nota elegida. Otras acciones reales relevantes: Ctrl+P elegir archivo; Ctrl+Shift+F buscar contenido; Abrir resultado y enfocar editor; Cerrar Esc.

REALITY / FEASIBILITY: Sólo carpeta local; Nombres de notas son DEMO; No buscar notas en Cloud ni mezclar con búsqueda global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S18-C · Switcher y ubicación de carpeta

**Layout desktop:** Diálogo 560px y pequeña vista contextual 220px de ruta de archivo/estado solo con metadata local.

**Layout móvil:** 390: ruta se muestra debajo de nombre y el editor queda atenuado detrás. Overlay con campo visible sobre teclado y scroll propio.

**Acción:** Resultado elegido muestra path local y «Abrir», no búsqueda Cloud. **Mejora:** Desambigua dos archivos de nombre parecido en carpetas diferentes.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S18-C, Abrir/buscar notas.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Abrir nota · Ctrl+P»; «Clase 7 — Matrices.md»; «Repaso parcial.md (demo)»; «Buscar en notas · Ctrl+Shift+F»; «Sin resultados».

DESKTOP 1440x900 WIREFRAME: Diálogo 560px y pequeña vista contextual 220px de ruta de archivo/estado solo con metadata local.

MOBILE 390x844 WIREFRAME: 390: ruta se muestra debajo de nombre y el editor queda atenuado detrás.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: editor de fondo → diálogo de notas → búsqueda → lista de archivos o matches → ayuda de atajos.

ACCIÓN VISIBLE / CONTROLS: Resultado elegido muestra path local y «Abrir», no búsqueda Cloud. Otras acciones reales relevantes: Ctrl+P elegir archivo; Ctrl+Shift+F buscar contenido; Abrir resultado y enfocar editor; Cerrar Esc.

REALITY / FEASIBILITY: Sólo carpeta local; Nombres de notas son DEMO; No buscar notas en Cloud ni mezclar con búsqueda global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S18-D · Navegá por archivos relacionados

**Layout desktop:** Switcher de notas con rutas jerárquicas existentes; wikilinks/búsqueda de contenido aparecen como acciones separadas.

**Layout móvil:** 390: jerarquía en segunda línea, acción «Buscar dentro de notas» explícita. Overlay con campo visible sobre teclado y scroll propio.

**Acción:** Ctrl+Shift+F abre búsqueda de contenido, Ctrl+P sigue abriendo archivo. **Mejora:** Da orientación en carpetas sin proponer grafo de conocimiento automático.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S18-D, Abrir/buscar notas.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Abrir nota · Ctrl+P»; «Clase 7 — Matrices.md»; «Repaso parcial.md (demo)»; «Buscar en notas · Ctrl+Shift+F»; «Sin resultados».

DESKTOP 1440x900 WIREFRAME: Switcher de notas con rutas jerárquicas existentes; wikilinks/búsqueda de contenido aparecen como acciones separadas.

MOBILE 390x844 WIREFRAME: 390: jerarquía en segunda línea, acción «Buscar dentro de notas» explícita.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: editor de fondo → diálogo de notas → búsqueda → lista de archivos o matches → ayuda de atajos.

ACCIÓN VISIBLE / CONTROLS: Ctrl+Shift+F abre búsqueda de contenido, Ctrl+P sigue abriendo archivo. Otras acciones reales relevantes: Ctrl+P elegir archivo; Ctrl+Shift+F buscar contenido; Abrir resultado y enfocar editor; Cerrar Esc.

REALITY / FEASIBILITY: Sólo carpeta local; Nombres de notas son DEMO; No buscar notas en Cloud ni mezclar con búsqueda global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S18-E · Tu archivo en una tecla

**Layout desktop:** Input «¿Qué nota querés abrir?» y tres resultados demo compactos, pie indica atajos reales; sin múltiples paneles.

**Layout móvil:** 390: campo enfocado y primer match visible sobre teclado, cerrar accesible. Overlay con campo visible sobre teclado y scroll propio.

**Acción:** Si no hay archivos: «Todavía no hay notas» y regresar editor, sin resultados fingidos. **Mejora:** Concentra el cambio de nota sin confundir la búsqueda académica.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 1440x900; one screen only, no device mockup or split before/after comparison. Screen ID S18-E, Abrir/buscar notas.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Abrir nota · Ctrl+P»; «Clase 7 — Matrices.md»; «Repaso parcial.md (demo)»; «Buscar en notas · Ctrl+Shift+F»; «Sin resultados».

DESKTOP 1440x900 WIREFRAME: Input «¿Qué nota querés abrir?» y tres resultados demo compactos, pie indica atajos reales; sin múltiples paneles.

MOBILE 390x844 WIREFRAME: 390: campo enfocado y primer match visible sobre teclado, cerrar accesible.

Muestra el viewport solicitado 1440x900 con esta estructura y priorización: editor de fondo → diálogo de notas → búsqueda → lista de archivos o matches → ayuda de atajos.

ACCIÓN VISIBLE / CONTROLS: Si no hay archivos: «Todavía no hay notas» y regresar editor, sin resultados fingidos. Otras acciones reales relevantes: Ctrl+P elegir archivo; Ctrl+Shift+F buscar contenido; Abrir resultado y enfocar editor; Cerrar Esc.

REALITY / FEASIBILITY: Sólo carpeta local; Nombres de notas son DEMO; No buscar notas en Cloud ni mezclar con búsqueda global. Sidebar real 220px con Hoy/Plan/Materias/Calendario/Notas/Material/Ajustes, Buscar (/) y Agregar. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S19 · Menú Más móvil

**Código real:** `src/components/academic-shell.tsx`, `src/components/nav-model.ts`. **Problema UX:** El último tab Más agrupa destinos y puede competir con el FAB en pantalla pequeña.

#### S19-A · Más, tres destinos claros

**Layout desktop:** En 1440 no hay menú: sidebar vertical Notas/Material/Ajustes con separadores; referencia móvil detallada.

**Layout móvil:** 390: popover de 260px sobre Más con tres filas Notas, Material, Ajustes y selección visible; + no se tapa. Popover sobre safe area; tres filas de al menos 44px.

**Acción:** Tocar Más abre, Escape/clic fuera cierra y devuelve foco. **Mejora:** Hace evidente dónde están funciones que no entran en barra móvil.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S19-A, Menú Más móvil.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Hoy»; «Plan»; «Materias»; «Calendario»; «Más»; «Notas»; «Material»; «Ajustes».

DESKTOP 1440x900 WIREFRAME: En 1440 no hay menú: sidebar vertical Notas/Material/Ajustes con separadores; referencia móvil detallada.

MOBILE 390x844 WIREFRAME: 390: popover de 260px sobre Más con tres filas Notas, Material, Ajustes y selección visible; + no se tapa.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: contexto actual → popover de tres destinos → tabbar con Más activo → FAB sin colisión.

ACCIÓN VISIBLE / CONTROLS: Tocar Más abre, Escape/clic fuera cierra y devuelve foco. Otras acciones reales relevantes: Tocar Más; Ir a Notas/Material/Ajustes; Cerrar tocando fuera; Cerrar con Escape.

REALITY / FEASIBILITY: Solo en ancho menor de 768px; En desktop se usa sidebar; No crear sexta tab persistente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S19-B · Accesos secundarios compactos

**Layout desktop:** Desktop lista fija de siete destinos en nav 220px; sin affordance Más.

**Layout móvil:** 390: popup alineado borde derecho con tres destinos, label+icon y áreas 48px. Popover sobre safe area; tres filas de al menos 44px.

**Acción:** Elegir Material cierra menú y navega; aria-expanded cambia con popup. **Mejora:** Mejora precisión táctil de menú y elimina ambigüedad de iconos solos.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S19-B, Menú Más móvil.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Hoy»; «Plan»; «Materias»; «Calendario»; «Más»; «Notas»; «Material»; «Ajustes».

DESKTOP 1440x900 WIREFRAME: Desktop lista fija de siete destinos en nav 220px; sin affordance Más.

MOBILE 390x844 WIREFRAME: 390: popup alineado borde derecho con tres destinos, label+icon y áreas 48px.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: contexto actual → popover de tres destinos → tabbar con Más activo → FAB sin colisión.

ACCIÓN VISIBLE / CONTROLS: Elegir Material cierra menú y navega; aria-expanded cambia con popup. Otras acciones reales relevantes: Tocar Más; Ir a Notas/Material/Ajustes; Cerrar tocando fuera; Cerrar con Escape.

REALITY / FEASIBILITY: Solo en ancho menor de 768px; En desktop se usa sidebar; No crear sexta tab persistente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S19-C · Menú y contexto del destino

**Layout desktop:** Desktop nav directa; ejemplo 390 incluye popover 280px con subtítulos «Archivos locales», «Links y notas breves», «Preferencias».

**Layout móvil:** 390: tres filas de 64px y subtítulos que no confunden Cloud/vault; posición lejos del FAB. Popover sobre safe area; tres filas de al menos 44px.

**Acción:** Cada fila completa navega; la ruta actual recibe marca de selección. **Mejora:** Explica diferencia Notas/Material en el punto donde se elige destino.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S19-C, Menú Más móvil.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Hoy»; «Plan»; «Materias»; «Calendario»; «Más»; «Notas»; «Material»; «Ajustes».

DESKTOP 1440x900 WIREFRAME: Desktop nav directa; ejemplo 390 incluye popover 280px con subtítulos «Archivos locales», «Links y notas breves», «Preferencias».

MOBILE 390x844 WIREFRAME: 390: tres filas de 64px y subtítulos que no confunden Cloud/vault; posición lejos del FAB.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: contexto actual → popover de tres destinos → tabbar con Más activo → FAB sin colisión.

ACCIÓN VISIBLE / CONTROLS: Cada fila completa navega; la ruta actual recibe marca de selección. Otras acciones reales relevantes: Tocar Más; Ir a Notas/Material/Ajustes; Cerrar tocando fuera; Cerrar con Escape.

REALITY / FEASIBILITY: Solo en ancho menor de 768px; En desktop se usa sidebar; No crear sexta tab persistente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S19-D · Mapa de áreas de Campus

**Layout desktop:** Desktop sidebar agrupada por áreas; en móvil Más es índice corto a Notas, Material y Ajustes sin crear nuevas rutas.

**Layout móvil:** 390: tres rutas como índice simple; indicación textual de que «Notas» requiere carpeta local. Popover sobre safe area; tres filas de al menos 44px.

**Acción:** Botón Más abre índice, elegir Notas lleva a /vault con fallback Cloud correcto. **Mejora:** Aclara jerarquía de navegación conservando destinos y contratos reales.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S19-D, Menú Más móvil.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Hoy»; «Plan»; «Materias»; «Calendario»; «Más»; «Notas»; «Material»; «Ajustes».

DESKTOP 1440x900 WIREFRAME: Desktop sidebar agrupada por áreas; en móvil Más es índice corto a Notas, Material y Ajustes sin crear nuevas rutas.

MOBILE 390x844 WIREFRAME: 390: tres rutas como índice simple; indicación textual de que «Notas» requiere carpeta local.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: contexto actual → popover de tres destinos → tabbar con Más activo → FAB sin colisión.

ACCIÓN VISIBLE / CONTROLS: Botón Más abre índice, elegir Notas lleva a /vault con fallback Cloud correcto. Otras acciones reales relevantes: Tocar Más; Ir a Notas/Material/Ajustes; Cerrar tocando fuera; Cerrar con Escape.

REALITY / FEASIBILITY: Solo en ancho menor de 768px; En desktop se usa sidebar; No crear sexta tab persistente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S19-E · Mostrar solo lo que falta

**Layout desktop:** Desktop sin menú popover; móvil Más abre sheet mínimo de tres filas, sin opciones terciarias.

**Layout móvil:** 390: popover anclado en barra y único destino por renglón; cerrar visible. Popover sobre safe area; tres filas de al menos 44px.

**Acción:** Al salir, foco vuelve a Más; FAB sigue separado para agregar fecha. **Mejora:** Reduce opciones simultáneas manteniendo top 4 tabs permanentes.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S19-E, Menú Más móvil.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «Hoy»; «Plan»; «Materias»; «Calendario»; «Más»; «Notas»; «Material»; «Ajustes».

DESKTOP 1440x900 WIREFRAME: Desktop sin menú popover; móvil Más abre sheet mínimo de tres filas, sin opciones terciarias.

MOBILE 390x844 WIREFRAME: 390: popover anclado en barra y único destino por renglón; cerrar visible.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: contexto actual → popover de tres destinos → tabbar con Más activo → FAB sin colisión.

ACCIÓN VISIBLE / CONTROLS: Al salir, foco vuelve a Más; FAB sigue separado para agregar fecha. Otras acciones reales relevantes: Tocar Más; Ir a Notas/Material/Ajustes; Cerrar tocando fuera; Cerrar con Escape.

REALITY / FEASIBILITY: Solo en ancho menor de 768px; En desktop se usa sidebar; No crear sexta tab persistente. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S20 · Resultado de final

**Código real:** `src/features/items/final-outcome-dialog.tsx`, `src/features/items/use-complete-item.tsx`. **Problema UX:** Completar fecha de final no significa aprobar materia y el usuario debe elegir resultado y opción de actualizarla.

#### S20-A · ¿Cómo te fue en el final?

**Layout desktop:** Modal 520px sobre calendario atenuado, título en Newsreader, tres opciones Aprobé/Desaprobé/Ausente, checkbox condicional, nota opcional.

**Layout móvil:** 390: radios 48px y botones Cancelar/Guardar abajo; actualización de materia explicada completa. Modal de una columna, radios 44px y confirmación visible.

**Acción:** Elegir Aprobé habilita «Marcar … como Aprobada»; Ausente no lo muestra. **Mejora:** Aclara que registrar resultado y actualizar materia son decisiones separadas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S20-A, Resultado de final.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Cómo te fue en Final de Arquitectura de Computadoras?»; «Aprobé»; «Desaprobé»; «Ausente»; «Marcar Arquitectura de Computadoras como Aprobada»; «Nota (opcional)»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Modal 520px sobre calendario atenuado, título en Newsreader, tres opciones Aprobé/Desaprobé/Ausente, checkbox condicional, nota opcional.

MOBILE 390x844 WIREFRAME: 390: radios 48px y botones Cancelar/Guardar abajo; actualización de materia explicada completa.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: pregunta → 3 radios → checkbox condicional → nota condicional → confirmación.

ACCIÓN VISIBLE / CONTROLS: Elegir Aprobé habilita «Marcar … como Aprobada»; Ausente no lo muestra. Otras acciones reales relevantes: Seleccionar Aprobé/Desaprobé/Ausente; Marcar o no actualizar materia si corresponde; Escribir nota opcional 1–10; Guardar o cancelar.

REALITY / FEASIBILITY: Ausente no ofrece cambio de materia; Nota opcional 1–10 con decimal; Cancelar deja estado sin cambios. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S20-B · Resultado, estado y nota

**Layout desktop:** Diálogo 520px con tres radios compactos, subgrupo Actualizar materia y nota decimal 1–10 condicional.

**Layout móvil:** 390: mismos controles apilados con feedback «La nota va de 1 a 10». Modal de una columna, radios 44px y confirmación visible.

**Acción:** Cambiar a Ausente quita update; Guardar solo si resultado elegido. **Mejora:** Hace explícitos efectos de aprobar/desaprobar y evita check prematuro de final.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S20-B, Resultado de final.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Cómo te fue en Final de Arquitectura de Computadoras?»; «Aprobé»; «Desaprobé»; «Ausente»; «Marcar Arquitectura de Computadoras como Aprobada»; «Nota (opcional)»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Diálogo 520px con tres radios compactos, subgrupo Actualizar materia y nota decimal 1–10 condicional.

MOBILE 390x844 WIREFRAME: 390: mismos controles apilados con feedback «La nota va de 1 a 10».

Muestra el viewport solicitado 390x844 con esta estructura y priorización: pregunta → 3 radios → checkbox condicional → nota condicional → confirmación.

ACCIÓN VISIBLE / CONTROLS: Cambiar a Ausente quita update; Guardar solo si resultado elegido. Otras acciones reales relevantes: Seleccionar Aprobé/Desaprobé/Ausente; Marcar o no actualizar materia si corresponde; Escribir nota opcional 1–10; Guardar o cancelar.

REALITY / FEASIBILITY: Ausente no ofrece cambio de materia; Nota opcional 1–10 con decimal; Cancelar deja estado sin cambios. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S20-C · Decisión con consecuencias

**Layout desktop:** Modal 540px y bloque auxiliar 210px que resume «Evento completado / Materia por actualizar: opcional» basado en elección real.

**Layout móvil:** 390: bloque de resumen después del checkbox, antes de botones. Modal de una columna, radios 44px y confirmación visible.

**Acción:** Checkbox Marca estado habilita nota; preview textual no guarda por sí solo. **Mejora:** Permite entender consecuencia de la opción de actualizar materia sin alterar reglas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S20-C, Resultado de final.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Cómo te fue en Final de Arquitectura de Computadoras?»; «Aprobé»; «Desaprobé»; «Ausente»; «Marcar Arquitectura de Computadoras como Aprobada»; «Nota (opcional)»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Modal 540px y bloque auxiliar 210px que resume «Evento completado / Materia por actualizar: opcional» basado en elección real.

MOBILE 390x844 WIREFRAME: 390: bloque de resumen después del checkbox, antes de botones.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: pregunta → 3 radios → checkbox condicional → nota condicional → confirmación.

ACCIÓN VISIBLE / CONTROLS: Checkbox Marca estado habilita nota; preview textual no guarda por sí solo. Otras acciones reales relevantes: Seleccionar Aprobé/Desaprobé/Ausente; Marcar o no actualizar materia si corresponde; Escribir nota opcional 1–10; Guardar o cancelar.

REALITY / FEASIBILITY: Ausente no ofrece cambio de materia; Nota opcional 1–10 con decimal; Cancelar deja estado sin cambios. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S20-D · Final y materia son dos estados

**Layout desktop:** Modal con dos pasos visuales simultáneos: «1 Resultado del final», «2 Actualizar materia si querés»; sin forzar wizard.

**Layout móvil:** 390: pasos apilados con radios grandes y nota opcional dentro del segundo. Modal de una columna, radios 44px y confirmación visible.

**Acción:** Ausente solo registra resultado, sin paso 2 activo; Cancelar conserva todo. **Mejora:** Enseña que final rendido y condición de materia no son equivalentes.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S20-D, Resultado de final.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Cómo te fue en Final de Arquitectura de Computadoras?»; «Aprobé»; «Desaprobé»; «Ausente»; «Marcar Arquitectura de Computadoras como Aprobada»; «Nota (opcional)»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Modal con dos pasos visuales simultáneos: «1 Resultado del final», «2 Actualizar materia si querés»; sin forzar wizard.

MOBILE 390x844 WIREFRAME: 390: pasos apilados con radios grandes y nota opcional dentro del segundo.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: pregunta → 3 radios → checkbox condicional → nota condicional → confirmación.

ACCIÓN VISIBLE / CONTROLS: Ausente solo registra resultado, sin paso 2 activo; Cancelar conserva todo. Otras acciones reales relevantes: Seleccionar Aprobé/Desaprobé/Ausente; Marcar o no actualizar materia si corresponde; Escribir nota opcional 1–10; Guardar o cancelar.

REALITY / FEASIBILITY: Ausente no ofrece cambio de materia; Nota opcional 1–10 con decimal; Cancelar deja estado sin cambios. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S20-E · Respondé cómo te fue

**Layout desktop:** Gran pregunta con radios Aprobé/Desaprobé/Ausente, detalles de materia aparecen solo si selección lo habilita.

**Layout móvil:** 390: una pregunta por pantalla visual, CTA Guardar visible al final, sin navegación de paso ficticia. Modal de una columna, radios 44px y confirmación visible.

**Acción:** Al elegir Aprobé aparece checkbox ya implementado y campo Nota (opcional). **Mejora:** Reduce la carga inicial mientras mantiene nota y actualización cuando corresponde.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S20-E, Resultado de final.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «¿Cómo te fue en Final de Arquitectura de Computadoras?»; «Aprobé»; «Desaprobé»; «Ausente»; «Marcar Arquitectura de Computadoras como Aprobada»; «Nota (opcional)»; «Guardar»; «Cancelar».

DESKTOP 1440x900 WIREFRAME: Gran pregunta con radios Aprobé/Desaprobé/Ausente, detalles de materia aparecen solo si selección lo habilita.

MOBILE 390x844 WIREFRAME: 390: una pregunta por pantalla visual, CTA Guardar visible al final, sin navegación de paso ficticia.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: pregunta → 3 radios → checkbox condicional → nota condicional → confirmación.

ACCIÓN VISIBLE / CONTROLS: Al elegir Aprobé aparece checkbox ya implementado y campo Nota (opcional). Otras acciones reales relevantes: Seleccionar Aprobé/Desaprobé/Ausente; Marcar o no actualizar materia si corresponde; Escribir nota opcional 1–10; Guardar o cancelar.

REALITY / FEASIBILITY: Ausente no ofrece cambio de materia; Nota opcional 1–10 con decimal; Cancelar deja estado sin cambios. Topbar Campus+Buscar, tabs inferiores Hoy/Plan/Materias/Calendario/Más, FAB sólo si esa ruta lo permite. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

### S21 · 404 y herramienta QA

**Código real:** `src/routes/__root.tsx`, `src/routes/dev.tsx`. **Problema UX:** Una ruta inválida debe dar salida clara; /dev es tester interno bloqueado cuando el flag está apagado.

#### S21-A · Ruta desconocida, salida conocida

**Layout desktop:** 404 en columna 520px con logo pequeño, título «No encontramos esta página» y vínculo claro Volver a Hoy; /dev documentado aparte.

**Layout móvil:** 390: mensaje y única acción debajo, sin barras de error técnicas. 404 mínimo y botón visible; variante dev interna separada.

**Acción:** Volver a Hoy mediante enlace visible; /dev sigue gateado. **Mejora:** Evita que ruta rota atrape usuario; no convierte tester en pantalla comercial.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S21-A, 404 y herramienta QA.

ESTILO / STYLE: Dirección A «Cuaderno editorial». La tarea académica es una página que se lee en orden: título expresivo, listas legibles, aire medido y separación por reglas. Background #FAF8F3, ink #202D2A, muted #536760, accent #176F68, rule #D9DED5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: filetes de 1 px, subtítulos bajo la acción, espaciado de capítulo, títulos expresivos sin hero.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «No encontramos esta página»; «Volver a Hoy»; «Herramientas de tester apagadas (estado interno alternativo)».

DESKTOP 1440x900 WIREFRAME: 404 en columna 520px con logo pequeño, título «No encontramos esta página» y vínculo claro Volver a Hoy; /dev documentado aparte.

MOBILE 390x844 WIREFRAME: 390: mensaje y única acción debajo, sin barras de error técnicas.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: marca mínima → mensaje de ruta inválida → volver → nota dev solo en anexo de QA.

ACCIÓN VISIBLE / CONTROLS: Volver a Hoy mediante enlace visible; /dev sigue gateado. Otras acciones reales relevantes: Volver a Hoy desde 404; Leer estado de tester solo en /dev; Cargar escenario solo en build de prueba habilitada.

REALITY / FEASIBILITY: No mostrar identidades ni credenciales del tester; No representar /dev como funcionalidad pública; No sugerir 404 como pantalla promocional. 404 autónomo, solo acción Volver a Hoy; /dev es entorno QA separado. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S21-B · Error 404 sin ruido

**Layout desktop:** Layout 520px con identificador 404 pequeño, mensaje, ruta de regreso y foco en enlace; sin stacktrace.

**Layout móvil:** 390: CTA Volver a Hoy área 48px, texto legible. 404 mínimo y botón visible; variante dev interna separada.

**Acción:** No ofrecer reintento de red en ruta inválida, solo navegación. **Mejora:** Diferencia error de ruta de error de datos académicos.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S21-B, 404 y herramienta QA.

ESTILO / STYLE: Dirección B «Agenda de precisión». Responder primero cuándo, de qué materia y en qué estado mediante filas compactas, fechas tabulares y filtros existentes. Background #F6F8F5, ink #18282C, muted #4D6269, accent #126A68, rule #CBD9D7. Type: Inter headlines and Inter interface, 14px regular body; minimal borders, no random cards or shadows. Motifs: columna de hora tabular, estados en texto compacto, conteos pequeños, cabeceras adheridas a su sección.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «No encontramos esta página»; «Volver a Hoy»; «Herramientas de tester apagadas (estado interno alternativo)».

DESKTOP 1440x900 WIREFRAME: Layout 520px con identificador 404 pequeño, mensaje, ruta de regreso y foco en enlace; sin stacktrace.

MOBILE 390x844 WIREFRAME: 390: CTA Volver a Hoy área 48px, texto legible.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: marca mínima → mensaje de ruta inválida → volver → nota dev solo en anexo de QA.

ACCIÓN VISIBLE / CONTROLS: No ofrecer reintento de red en ruta inválida, solo navegación. Otras acciones reales relevantes: Volver a Hoy desde 404; Leer estado de tester solo en /dev; Cargar escenario solo en build de prueba habilitada.

REALITY / FEASIBILITY: No mostrar identidades ni credenciales del tester; No representar /dev como funcionalidad pública; No sugerir 404 como pantalla promocional. 404 autónomo, solo acción Volver a Hoy; /dev es entorno QA separado. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S21-C · Ruta y contexto de recuperación

**Layout desktop:** 404 a izquierda 450px, derecha 220px lista de destinos de navegación existentes solo en entorno con shell; no crear ruta.

**Layout móvil:** 390: destinos bajo Volver a Hoy, sin sidebar secundaria. 404 mínimo y botón visible; variante dev interna separada.

**Acción:** Enlaces a Hoy/Plan/Materias únicamente cuando app route guard los admite. **Mejora:** Ayuda a retomar plan/calendario tras URL incorrecta sin simular recuperación de sesión.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S21-C, 404 y herramienta QA.

ESTILO / STYLE: Dirección C «Mesa contextual». Colocar la acción primaria junto al contexto académico real que explica su importancia, sin añadir funcionalidades. Background #F7F6F0, ink #233039, muted #5C6668, accent #226F7A, rule #D7DEDA. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: mesa de dos zonas, contexto de carrera solo cuando existe, líneas de columna en vez de tarjetas, sin rail vacío.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «No encontramos esta página»; «Volver a Hoy»; «Herramientas de tester apagadas (estado interno alternativo)».

DESKTOP 1440x900 WIREFRAME: 404 a izquierda 450px, derecha 220px lista de destinos de navegación existentes solo en entorno con shell; no crear ruta.

MOBILE 390x844 WIREFRAME: 390: destinos bajo Volver a Hoy, sin sidebar secundaria.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: marca mínima → mensaje de ruta inválida → volver → nota dev solo en anexo de QA.

ACCIÓN VISIBLE / CONTROLS: Enlaces a Hoy/Plan/Materias únicamente cuando app route guard los admite. Otras acciones reales relevantes: Volver a Hoy desde 404; Leer estado de tester solo en /dev; Cargar escenario solo en build de prueba habilitada.

REALITY / FEASIBILITY: No mostrar identidades ni credenciales del tester; No representar /dev como funcionalidad pública; No sugerir 404 como pantalla promocional. 404 autónomo, solo acción Volver a Hoy; /dev es entorno QA separado. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S21-D · Mapa de retorno

**Layout desktop:** Hoja con breve ruta «Página no encontrada → Hoy → Materias/Plan», flechas como texto estático; 404 se explica.

**Layout móvil:** 390: secuencia vertical corta y un solo vínculo real Volver a Hoy. 404 mínimo y botón visible; variante dev interna separada.

**Acción:** El único CTA activo es regresar a ruta válida. **Mejora:** Expone continuidad de navegación sin confundirla con correlativas académicas.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S21-D, 404 y herramienta QA.

ESTILO / STYLE: Dirección D «Mapa académico». Orientación por relaciones textuales entre materias, hitos, estados y correlativas verificadas; nunca un grafo construido sin datos. Background #F6F8F2, ink #20332E, muted #596D61, accent #247362, rule #D2DFD5. Type: Newsreader headlines and Inter interface, 15px regular body; minimal borders, no random cards or shadows. Motifs: líneas de relación solo entre datos conocidos, rutas textuales Requiere/Habilita, año y estado sin inferencias, estados desconocidos explícitos.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «No encontramos esta página»; «Volver a Hoy»; «Herramientas de tester apagadas (estado interno alternativo)».

DESKTOP 1440x900 WIREFRAME: Hoja con breve ruta «Página no encontrada → Hoy → Materias/Plan», flechas como texto estático; 404 se explica.

MOBILE 390x844 WIREFRAME: 390: secuencia vertical corta y un solo vínculo real Volver a Hoy.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: marca mínima → mensaje de ruta inválida → volver → nota dev solo en anexo de QA.

ACCIÓN VISIBLE / CONTROLS: El único CTA activo es regresar a ruta válida. Otras acciones reales relevantes: Volver a Hoy desde 404; Leer estado de tester solo en /dev; Cargar escenario solo en build de prueba habilitada.

REALITY / FEASIBILITY: No mostrar identidades ni credenciales del tester; No representar /dev como funcionalidad pública; No sugerir 404 como pantalla promocional. 404 autónomo, solo acción Volver a Hoy; /dev es entorno QA separado. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

#### S21-E · Un camino de regreso

**Layout desktop:** Centro 500px con mensaje de una línea y CTA primario Volver a Hoy; tester off como caso aparte de QA sin mostrar aquí.

**Layout móvil:** 390: nada más que causa legible y botón; máximo 2 líneas de título. 404 mínimo y botón visible; variante dev interna separada.

**Acción:** Enlace enfocable, sin enlace directo a herramientas internas. **Mejora:** Reduce fricción para salir de un estado terminal de navegación.

```text
GENERATE ONE ORIGINAL HIGH-FIDELITY, FRONT-ON, PIXEL-ALIGNED CAMPUS WEB UI CONCEPT. Single frame 390x844; one screen only, no device mockup or split before/after comparison. Screen ID S21-E, 404 y herramienta QA.

ESTILO / STYLE: Dirección E «Foco progresivo». Una decisión clara por vez y detalles secundarios visibles bajo demanda, preservando acciones y datos del producto. Background #FAFBF6, ink #172D29, muted #546960, accent #1B7465, rule #D6E2D9. Type: Newsreader headlines and Inter interface, 16px regular body; minimal borders, no random cards or shadows. Motifs: una acción principal, bloques desplegables etiquetados, detalles secundarias después del dato urgente, confirmación textual.

COPY EXACTA EN ESPAÑOL ARGENTINO / EXACT UI COPY: «No encontramos esta página»; «Volver a Hoy»; «Herramientas de tester apagadas (estado interno alternativo)».

DESKTOP 1440x900 WIREFRAME: Centro 500px con mensaje de una línea y CTA primario Volver a Hoy; tester off como caso aparte de QA sin mostrar aquí.

MOBILE 390x844 WIREFRAME: 390: nada más que causa legible y botón; máximo 2 líneas de título.

Muestra el viewport solicitado 390x844 con esta estructura y priorización: marca mínima → mensaje de ruta inválida → volver → nota dev solo en anexo de QA.

ACCIÓN VISIBLE / CONTROLS: Enlace enfocable, sin enlace directo a herramientas internas. Otras acciones reales relevantes: Volver a Hoy desde 404; Leer estado de tester solo en /dev; Cargar escenario solo en build de prueba habilitada.

REALITY / FEASIBILITY: No mostrar identidades ni credenciales del tester; No representar /dev como funcionalidad pública; No sugerir 404 como pantalla promocional. 404 autónomo, solo acción Volver a Hoy; /dev es entorno QA separado. Para este concepto el estado dibujado debe estar claramente basado en el fixture de referencia, y los cambios propuestos son FUTURO.

ACCESSIBILITY AND RESPONSIVE: logical reading order, visible 2px focus, text plus status color, strong contrast, 44px target for touch; neither horizontal overflow nor obscured mobile bottom navigation.

NEGATIVE REQUIREMENTS: Do not depict a phone, laptop, desk, stock photography, 3D perspective, AI assistant, false backend, fake loading completion, gradient-glass gimmicks or a dashboard of invented metrics. Do not fabricate features: no Cloud file editor or vault sync, no drag-to-reschedule, no invisible academic prerequisites, no automatic exam pass, no SSO, no upload of PDF files. No Juxtopposed branding or copied mockup; original Campus language and composition. Typography must be crisp legible real Spanish copy, not lorem ipsum or nonsense; use only the supplied demo labels.
```

