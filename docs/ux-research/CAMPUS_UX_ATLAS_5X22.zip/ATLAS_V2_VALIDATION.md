# Campus · Atlas V2 — verificación del entregable HTML

**Archivo:** [`ATLAS_CAMPUS_V2.html`](ATLAS_CAMPUS_V2.html) · **Corte de validación:** 26/10/2026.

## Cobertura y procedencia

- **22 superficies S00–S21** del [`SCREEN_INVENTORY.md`](SCREEN_INVENTORY.md), con contenido específico para elección local/Cloud, acceso, onboarding, progreso, Hoy, plan, lista/tablero, materia, los tres calendarios, material, notas, estado Cloud, ajustes, tres overlays de búsqueda/captura, menú móvil, resultado de final y QA/404.
- **Cinco direcciones A–E** diferenciadas en composición/tokens: Cuaderno editorial; Agenda de precisión; Mesa contextual; Mapa académico; Foco progresivo. Cada par pantalla/dirección posee texto de mejora, acción y riesgo específico, integrado en el HTML desde los **110 registros** de `atlas5/ATLAS_SPEC.json` con un snapshot autocontenido. El HTML no necesita `fetch` ni otro archivo para funcionar; los links de bibliografía remiten a los documentos de investigación junto al HTML o a las fuentes primarias en internet.
- Tres marcos virtuales: **390×844, 768×1024 y 1440×900**. La interfaz de revisión abre de forma predeterminada con **A ampliada** y permite alternar a vista simultánea de cinco miniaturas. La precisión de los tamaños es interna al prototipo; esto no equivale a haber probado Campus real a esas resoluciones.
- `S04` conserva el escenario del **24/10/2026** en `proposals/SCENARIO.md`: una atrasada, dos del día, dos próximas, una sin fecha, tres materias cursando y dos finales pendientes. No se inventan porcentajes, horarios ni materias para completar el dibujo.

## Verificaciones ejecutadas

| Verificación | Resultado observado |
|---|---|
| Parseo JavaScript | `node --check` del `<script>` extraído: **PASS**. |
| Render sintético | `window.__ATLAS_QA__.renderOne` sobre **22 × 5 × 3 = 330 combinaciones**: **0 excepciones**, ID/variante/viewport correctos. |
| Carga de navegador | Chromium conectado, HTML servido localmente: título, índice, 5 direcciones y escenario Hoy renderizados sin errores visibles. |
| Navegación y filtros | Índice: 22 entradas; filtro `S13`: 1 coincidencia; restaurar filtro: 22. |
| Cambio de modo | Vista ampliada: 1 prototipo grande; comparación: 5 miniaturas; selección de D: carga específica con texto S04-D. |
| Cambio de ancho | Botón móvil: aparece barra superior e inferior; sidebar se oculta. Escritorio: sidebar visible. |
| Revisión local | Selector de estado para S04-D persiste la elección en `localStorage`, verificable mediante lectura posterior. |
| Desbordamiento de la página | En sesión Chromium a `innerWidth=1912`: diferencia `scrollWidth-innerWidth = 0`. |

## Límites materiales

1. **0 imágenes nativas ImageGen**: las 110 superficies son conceptos de **HTML/CSS renderizable**, etiquetados como tales. Las imágenes generadas originales siguen pendientes y requieren herramienta ImageGen nativa. Cualquier captura del navegador de este atlas sería una captura de prototipo, nunca un resultado ImageGen ni una captura de producción.
2. El código de Campus no se modificó ni se levantó con datos reales. Las hipótesis de usabilidad y accesibilidad aún necesitan pruebas de estudiantes, casos de carga/vacío/error y comparación con capturas del producto real. No se certificaron WCAG ni interacciones dentro de cada maqueta: el interior de los prototipos es ilustrativo y tiene `aria-hidden`; los controles reales pertenecen al atlas de revisión.
3. No se probó el **viewport externo** de navegador a 390/768; se probó el conmutador de tres marcos simulados y el sitio externo en un navegador de escritorio. La inspección de tamaños reales, foco al cerrar diálogos y comportamiento bajo teclado móvil permanece pendiente para la aplicación futura.
4. Los gráficos/relaciones de D, el panel contextual C y el plegado conceptual E son **candidatos FUTURO**, no capacidades implementadas. Las correlativas desconocidas se rotulan en vez de dibujar desbloqueos calculados.

No hubo publicación ni despliegue del atlas. La UI de producto, los archivos ajenos y `src/routeTree.gen.ts` permanecieron fuera del alcance de este worker.
